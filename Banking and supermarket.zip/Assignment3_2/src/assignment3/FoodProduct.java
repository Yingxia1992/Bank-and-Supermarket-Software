/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import javax.swing.JTextArea;

/**
 *
 * @author aaa
 */
public class FoodProduct extends Product{
     private String Weight;
     private String WeightUnit;
     private String ExpiryDate;
     private String UseByDate;
     private String SoldByDate;
     private File FoodProductFile;
    
   public FoodProduct(){
       super();
       Edit("","","","","");
   }
   public FoodProduct(String strID,String strName,Integer intMax,Integer intMin,Double douPriceWithoutVAT,String strEstimate,Integer intQuantityInStock,
            String strCategory,String strDD,String strLOD,String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry,
            String strWeight,String strWeightUnit,String strExpiryDate,String strUseByDate,String strSoldByDate){
       super(strID, strName, intMax,  intMin, douPriceWithoutVAT, strEstimate, intQuantityInStock, strCategory, strDD, strLOD,
                strname, strDN, strPN, strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
       Edit(strWeight,strWeightUnit,strExpiryDate,strUseByDate,strSoldByDate);
   }
   
   public void Edit(String strWeight,String strWeightUnit,String strExpiryDate,String strUseByDate,String strSoldByDate){
       this.Weight=strWeight;
       this.WeightUnit=strWeightUnit;
       this.ExpiryDate=strExpiryDate;
       this.UseByDate=strUseByDate;
       this.SoldByDate=strSoldByDate;
   }
   public void setFoodProduct(String strID,String strName,Integer intMax,Integer intMin,Double douPriceWithoutVAT,String strEstimate,Integer intQuantityInStock,
            String strCategory,String strDD,String strLOD,String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry,
            String strWeight,String strWeightUnit,String strExpiryDate,String strUseByDate,String strSoldByDate){
        super.Edit(strID, strName, intMax,  intMin, douPriceWithoutVAT, strEstimate, intQuantityInStock, strCategory, strDD, strLOD,
                strname, strDN, strPN, strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
       Edit(strWeight,strWeightUnit,strExpiryDate,strUseByDate,strSoldByDate);
   }
   
   public File CreateFolder(){
        File folder=new File(super.CreateFolder()+"/"+"FoodProducts.txt");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir())
            {
                System.out.println("The Food_Products folder is created");
            }
            else
            {
                System.out.println("Failed to create the Food_Products folder");
            }
        }
        return folder;
    }
   
   public String getString(){
       return String.format(super.getString()+Weight+"\n"+WeightUnit+"\n"+ExpiryDate+"\n"+UseByDate+"\n"+SoldByDate);
   }
   public File SaveToFile(){
        
        FoodProductFile=new File(CreateFolder()+"/"+this.getName()+"_load.txt");
        FileWriter writer;
        try{
            writer=new FileWriter(FoodProductFile,false);
            
            writer.write(getString()+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
        }catch(IOException ioe){
        }
        System.out.println("Save Food Product");
        return FoodProductFile;
        
    }

   public FoodProduct LoadFromFile(String theFood){
       try{
           BufferedReader bin=new BufferedReader(new FileReader(theFood));
           
           setFoodProduct(bin.readLine(),bin.readLine(),Integer.valueOf( bin.readLine()),Integer.valueOf(bin.readLine()),Double.valueOf(bin.readLine()),
                        bin.readLine(),Integer.valueOf(bin.readLine()),bin.readLine(),bin.readLine(),bin.readLine(),
                        bin.readLine(),bin.readLine(),bin.readLine(),
                        bin.readLine(),Integer.valueOf(bin.readLine()),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine(),
                        bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine());
           System.out.println("Load Food Product Information");
           bin.close();
           bin=null;
           return this;
       }catch(IOException ioe){
           
       }
       return null;
   }
   
   public void Display(JTextArea jta){
       super.Display(jta);
       jta.append("Type of product: Food Product"+"\nWeight: "+Weight+WeightUnit+"\nExpiry Date: "+ExpiryDate+"\nUse by date: "
       +UseByDate+"\nSold by date: "+SoldByDate);
   }
}
