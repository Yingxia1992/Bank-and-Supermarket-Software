/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.DefaultListModel;

/**
 *
 * @author aaa
 */
public class WishList extends ProductList{
    ArrayList<Product> WishProducts;
    private User theUser;
    private File folder;
    public WishList(){
        super();
        WishProducts=new ArrayList<Product>();
//        theUser=new User();
        folder=new File("WishList_Folder");
//        LoadFromFile();
    }
//    public WishList(User src){
//        this.theUser=src;
//        src.setWishList(this);
////        LoadFromFile(src);
//    }
    
    
//    public String CreateWishList(String Name){
//        return Name;
//    }
    public void Add(int index,User U){
//        for(int i=0;i<theProducts.size();i++){
//            if(i==index){
//                WishProducts.add(theProducts.get(i));
//            }
//        }
         System.out.println("prd："+getProduct(index).getName());
        theUser=new User(U);
        WishProducts.add(getProduct(index));
//        for (int i = 0; i < WishProducts.size(); i++) {
//            System.out.println("prd："+getProduct(index).getName());
//        }
        SaveToFile(U);
        
    }
    
    public User getUser(){
        return theUser;
    }
    
    public DefaultListModel WisihList(DefaultListModel model){
        for(int i=0;i<WishProducts.size();i++){
            model.addElement(WishProducts.get(i).getName());
        }
        return model;
    }
     public void Display(javax.swing.JTextArea jta, int index){
        jta.setText("");
        for(int i=0;i<WishProducts.size();i++){
            if(i==index){
                WishProducts.get(i).Display(jta);
            }
        }
    }
     public void SaveToFile(User U){
         
         folder.mkdir();
         FileWriter writer;
         File F=new File(folder+"/"+U.getFullName()+"_load.txt");
         System.out.println(F);
//         if(F.exists()){
//             System.out.println("this file exists");
//         }
//         else{
//             System.out.println("not exists");
//         }
//         theUser=new User();
         try{
             
             writer=new FileWriter(F,true);
             for(int i=0;i<WishProducts.size();i++){
                 writer.write(WishProducts.get(i).getName()+System.getProperty("line.separator"));
                 System.out.println("wish："+U.getFullName());
             }
             writer.flush();
             writer.close();
//             writer=null;
             System.out.println("Save WishList");
         }catch(IOException ioe){
             
         }
     }
     public void LoadFromFile(File WishListFile){
//         theUser=new User();
//         File F=new File(folder+"/"+theUser.getFullName()+"_load.txt");
         System.out.println("Load wish list");
         String ProductName;
         try{
             FileReader reader = new FileReader(WishListFile);
             BufferedReader bin=new BufferedReader(reader);
             while((ProductName=bin.readLine())!=null){
                 System.out.println("read a line");
                 WishProducts.add(this.getProduct(ProductName));
                 System.out.println(WishProducts);
             }
             bin.close();
             bin=null;
             
         }catch(IOException ioe){
             
         }
     }   
//     public void setCustomer(User C){
//         theUser=new User(C);
//     }
//     public User getCustomer(){
//         return theUser;
//     }

}
