/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.util.ArrayList;
import javax.swing.DefaultListModel;

/**
 *
 * @author aaa
 */
public class ReorderList extends ProductList{
     ArrayList<Product> ReorderProducts;
    public ReorderList(){
        super();
        ReorderProducts=new ArrayList<Product>();
        Reorder();
    }
     public void Reorder(){
         
        for(int i=0;i<theProducts.size();i++){
            if((theProducts.get(i).getMin())>(theProducts.get(i).getQuantiry())){
                ReorderProducts.add(theProducts.get(i));
                System.out.println("Add Reorder Product");
            }
        }
    }
    public DefaultListModel ReorderList(DefaultListModel model){
        for(int i=0;i<ReorderProducts.size();i++){
            model.addElement(ReorderProducts.get(i).getName());
        }
        return model;
    }
     public void DisplayReorder(javax.swing.JTextArea jReorderTextArea, int index){
        jReorderTextArea.setText("");
        for(int i=0;i<ReorderProducts.size();i++){
            if(i==index){
                ReorderProducts.get(i).DisplayReorderProduct(jReorderTextArea);
            }
        }
    }
     
}
