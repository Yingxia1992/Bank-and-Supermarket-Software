/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JTextArea;

/**
 *
 * @author aaa
 */
public class CrockeryProduct extends Product{
    private String Size;
    private String Colour;
    private File CrockeryProductFile;
    
    public CrockeryProduct(){
        super();
        Edit("","");
    }
    public CrockeryProduct(String strID,String strName,Integer intMax,Integer intMin,Double douPriceWithoutVAT,String strEstimate,Integer intQuantityInStock,
            String strCategory,String strDD,String strLOD,String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry,String strSize,String strColour){
        super(strID, strName, intMax,  intMin, douPriceWithoutVAT, strEstimate, intQuantityInStock, strCategory, strDD, strLOD,
                strname, strDN, strPN, strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
        Edit(strSize,strColour);
    }
    
    
    
    public void Edit(String strSize,String strColour){
        this.Size=strSize;
        this.Colour=strColour;
    }
    public void setCrockeryProduct(String strID,String strName,Integer intMax,Integer intMin,Double douPriceWithoutVAT,String strEstimate,Integer intQuantityInStock,
            String strCategory,String strDD,String strLOD,String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry,String strSize,String strColour){
        super.Edit(strID, strName, intMax,  intMin, douPriceWithoutVAT, strEstimate, intQuantityInStock, strCategory, strDD, strLOD,
                strname, strDN, strPN, strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
        Edit(strSize,strColour);
    }
    
     public File CreateFolder(){
        File folder=new File(super.CreateFolder()+"/"+"CrockeryProducts.txt");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir())
            {
                System.out.println("The Crockery_Products folder is created");
            }
            else
            {
                System.out.println("Failed to create the Crockery_Products folder");
            }
        }
        return folder;
    }
   
   public String getString(){
       return String.format(super.getString()+this.Size+"\n"+this.Colour+"\n");
   }
   public File SaveToFile(){
        
        CrockeryProductFile=new File(CreateFolder()+"/"+this.getName()+"_load.txt");
        FileWriter writer;
        try{
            writer=new FileWriter(CrockeryProductFile,false);
            
            writer.write(getString()+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
        }catch(IOException ioe){
        }
        System.out.println("Save Crockery Product");
        return CrockeryProductFile;
        
    }
   public CrockeryProduct LoadFromFile(String theFood){
       try{
           BufferedReader bin=new BufferedReader(new FileReader(theFood));
           
           setCrockeryProduct(bin.readLine(),bin.readLine(),Integer.valueOf( bin.readLine()),Integer.valueOf(bin.readLine()),Double.valueOf(bin.readLine()),
                        bin.readLine(),Integer.valueOf(bin.readLine()),bin.readLine(),bin.readLine(),bin.readLine(),
                        bin.readLine(),bin.readLine(),bin.readLine(),
                        bin.readLine(),Integer.valueOf(bin.readLine()),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine(),
                        bin.readLine(),bin.readLine());
           System.out.println("Load Crockery Product Information");
           bin.close();
           bin=null;
           return this;
       }catch(IOException ioe){
           
       }
       return null;
   }
   public void Display(JTextArea jta){
       super.Display(jta);
       jta.append("Type of product: Crockery Product"+"\nSize: "+Size+"\nColour: "+Colour);
   }
}
