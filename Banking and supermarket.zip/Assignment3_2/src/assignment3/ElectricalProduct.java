/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JTextArea;

/**
 *
 * @author aaa
 */
public class ElectricalProduct extends Product{
    private String GuranteeDuration;
    private File ElectricalProductFile;
    
    public ElectricalProduct(){
        super();
        Edit("");
    }
    public ElectricalProduct(String strID,String strName,Integer intMax,Integer intMin,Double douPriceWithoutVAT,String strEstimate,Integer intQuantityInStock,
            String strCategory,String strDD,String strLOD,String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry,String strGD){
       super(strID, strName, intMax,  intMin, douPriceWithoutVAT, strEstimate, intQuantityInStock, strCategory, strDD, strLOD,
                strname, strDN, strPN, strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
        Edit(strGD);
    }
    
    public void Edit(String strGD){
        this.GuranteeDuration=strGD;
    }
    public void setElectricalProduct(String strID,String strName,Integer intMax,Integer intMin,Double douPriceWithoutVAT,String strEstimate,Integer intQuantityInStock,
            String strCategory,String strDD,String strLOD,String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry,String strGD){
        super.Edit(strID, strName, intMax,  intMin, douPriceWithoutVAT, strEstimate, intQuantityInStock, strCategory, strDD, strLOD,
                strname, strDN, strPN, strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
        Edit(strGD);
    }
    public File CreateFolder(){
        File folder=new File(super.CreateFolder()+"/"+"ElectricalProducts.txt");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir())
            {
                System.out.println("The Electrical_Products folder is created");
            }
            else
            {
                System.out.println("Failed to create the Electrical_Products folder");
            }
        }
        return folder;
    }
   
   public String getString(){
       return String.format(super.getString()+this.GuranteeDuration);
   }
   public File SaveToFile(){
        
        ElectricalProductFile=new File(CreateFolder()+"/"+this.getName()+"_load.txt");
        FileWriter writer;
        try{
            writer=new FileWriter(ElectricalProductFile,false);
            
            writer.write(getString()+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
        }catch(IOException ioe){
        }
        System.out.println("Save Electrical Product");
        return ElectricalProductFile;
        
    }
   public ElectricalProduct LoadFromFile(String theFood){
       try{
           BufferedReader bin=new BufferedReader(new FileReader(theFood));
           
           setElectricalProduct(bin.readLine(),bin.readLine(),Integer.valueOf( bin.readLine()),Integer.valueOf(bin.readLine()),Double.valueOf(bin.readLine()),
                        bin.readLine(),Integer.valueOf(bin.readLine()),bin.readLine(),bin.readLine(),bin.readLine(),
                        bin.readLine(),bin.readLine(),bin.readLine(),
                        bin.readLine(),Integer.valueOf(bin.readLine()),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine(),
                        bin.readLine());
           System.out.println("Load Food Product Information");
           bin.close();
           bin=null;
           return this;
       }catch(IOException ioe){
           
       }
       return null;
   }
    public void Display(JTextArea jta){
       super.Display(jta);
       jta.append("Type of product: Electrical Product"+"\nGurantee Duration: "+GuranteeDuration);
   }
}
