/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author aaa
 */
public class UserList {
    private ArrayList<User> theUsers;
    private ArrayList<String> File_Location;
//    private File WishListFile;
    
    public UserList(){
        theUsers=new ArrayList<User>();
        File_Location=new ArrayList<String>();
        LoadFromFile();
    }
    
    public void CreateUser(User U){
        theUsers.add(U);
        File_Location.add(String.valueOf(U.SaveToFile()));
        U.SaveToFile();
//        WishList WL=new WishList(U);
//        U.setWishList(WL);
//        U.CreateWishListFile();
        SaveLocation();
    }
    
    public void SaveLocation(){
        FileWriter writer;
        try{
            writer=new FileWriter("UserFileLocation.txt",true);
            for(int i=0;i<File_Location.size();i++){
                writer.write(File_Location.get(i)+System.getProperty("line.separator"));
            }
            writer.flush();
            writer.close();
            writer=null;
        }catch(IOException ioe){
            
        }
    }
    public void LoadFromFile(){
        String theCurrentLine;
        try{
            BufferedReader bin=new BufferedReader(new FileReader("UserFileLocation.txt"));
            while((theCurrentLine=bin.readLine())!=null){
                User U=new User();
                theUsers.add(U.LoadFromFile(theCurrentLine));
//                WishList WL=new WishList(U.LoadFromFile(theCurrentLine));
//                U.LoadFromFile(theCurrentLine).setWishList(WL);
            }
            bin.close();
            bin=null;
        }catch(IOException ioe){
            
        }
    }
    
    public User Search(User U){
        for(int i=0;i<theUsers.size();i++){
            if(U.getFirstName().equals(theUsers.get(i).getFirstName())){
                if(U.getSurname().equals(theUsers.get(i).getSurname())){
                    if(U.getPassword().equals(theUsers.get(i).getPassword())){
                        if(U.getRole().equals(theUsers.get(i).getRole())){
                            return theUsers.get(i);
                        }
                    }
                }
            }
        }
        return null;
    }
    
//    public File CreateWishListFile(){
//        File folder=new File("WishList_Folder");
//        folder.mkdir();
//        for(int i=0;i<theUsers.size();i++){
//            WishListFile=new File(folder+"/"+theUsers.get(i).getFullName()+"_load.txt");
//            return WishListFile;
//        }
//        return null;
//    }
    
    
}
