/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JTextArea;

/**
 *
 * @author aaa
 */
public class Supplier {
    private String Name;
    private String DirectorName;
    private String PhoneNumber;
    private IAddress CompanyAddress;
    
    public Supplier(){
       CompanyAddress=new IAddress();
       Edit("","","");
    }
    
    public Supplier(String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry){
        Edit(strname,strDN,strPN);
        CompanyAddress = new IAddress(strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
    }
    
    public void Edit(String strname, String strDN, String strPN){
        this.Name=strname;
        this.DirectorName=strDN;
        this.PhoneNumber=strPN;
    }
    
    public void Edit(String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry){
        Edit(strname,strDN,strPN);
        CompanyAddress.Edit(strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
    }
    
    public void Display(JTextArea jta){
        jta.setLineWrap(true);
        jta.append("Supplier Name: "+Name+"\nDirector Name: "+DirectorName+"\nPhone Number: "+PhoneNumber+"\n");
        CompanyAddress.Display(jta);
    }
    
    public IAddress getAddress(){
        return CompanyAddress;
    }
    public String getString(){
        return String.format(Name+"\n"+DirectorName+"\n"+PhoneNumber+"\n"+CompanyAddress.getString());
    }
    
//    public void SaveToFile(File SupplierDetail){
//        FileWriter writer;
//        try{
//            writer=new FileWriter(SupplierDetail,true);
//            writer.write(Name+System.getProperty("line.separator"));
//            writer.write(DirectorName+System.getProperty("line.separator"));
//            writer.write(PhoneNumber+System.getProperty("line.separator"));
//            writer.flush();
//            writer.close();
//            writer=null;
//        }catch(IOException ioe){
//            
//        }
//        CompanyAddress.SaveToFile(SupplierDetail);
//    }
//    public void Display(javax.swing.JTextArea jAddressTextArea){
//        jAddressTextArea.setLineWrap(true);
//        jAddressTextArea.append("Name: "+Name+"\nStreet: "+Street+"\nHouse_No: "+HouseNo+"\nHouse_Name: "+HouseName+"\nArea: "+Area+
//        "\nPostCode: "+PostCode+"\nTown: "+Town+"\nCountry: "+Country+"\n\n");
//    }
//    public void Edit(String strname,String strstreet,Integer inthouse_no,String strhouse_name,
//            String strarea,String strpost_code,String strtown,String strcountry){
//        this.Name=strname;
//        this.Street=strstreet;
//        this.HouseNo=inthouse_no;
//        this.HouseName=strhouse_name;
//        this.Area=strarea;
//        this.PostCode=strpost_code;
//        this.Town=strtown;
//        this.Country=strcountry;
//    }
//    
//    public String getName(){
//        return Name;
//    }
//    public String getStreet(){
//        return Street;
//    }
//    public Integer getHouseNo(){
//        return HouseNo;
//    }
//    public String getHouseName(){
//        return HouseName;
//    }
//    public String getArea(){
//        return Area;
//    }
//    public String getPostCode(){
//        return PostCode;
//    }
//    public String getTown(){
//        return Town;
//    }
//    public String getCountry(){
//        return Country;
//    }
}
