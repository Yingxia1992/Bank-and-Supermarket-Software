/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import javax.swing.DefaultListModel;

/**
 *
 * @author aaa
 */
public class ProductList {
    
    ArrayList<Product> theProducts;
    ArrayList<String> ProductFileLocation;

     private File File_Location;
    
    
    public ProductList(){
      
        theProducts=new ArrayList<Product>();
        ProductFileLocation=new ArrayList<String>();
         File_Location=new File("File_Location.txt");
                 
        LoadLocation();
    }
    
    public void Add(Product newProduct){
        
        theProducts.add(newProduct);
        ProductFileLocation.add(String.valueOf(newProduct.SaveToFile()));
        newProduct.SaveToFile();
        SaveDirectoryLocation();
    }
//    public void AddFood(FoodProduct newProduct){
//        theProducts.add(newProduct);
//        ProductFileLocation.add(String.valueOf(newProduct.SaveToFile()));
//        newProduct.SaveToFile();
//        SaveDirectoryLocation();
//    }
//    public void AddElectrical(ElectricalProduct newProduct){
//        theProducts.add(newProduct);
//        ProductFileLocation.add(String.valueOf(newProduct.SaveToFile()));
//        newProduct.SaveToFile();
//        SaveDirectoryLocation();
//    }
//    public void AddCrockery(CrockeryProduct newProduct){
//        theProducts.add(newProduct);
//        ProductFileLocation.add(String.valueOf(newProduct.SaveToFile()));
//        newProduct.SaveToFile();
//        SaveDirectoryLocation();
//    }
    
    public void SaveDirectoryLocation(){
        FileWriter writer;
        try{
            writer=new FileWriter(File_Location,true);
            for(int i=0;i<ProductFileLocation.size();i++){
                writer.write(ProductFileLocation.get(i)+System.getProperty("line.separator"));
            }
            writer.flush();
            writer.close();
            writer=null;
        }catch(IOException ioe){
            
        }
        
    }
    
//    public void Edit(String strID,String strName,Double strP,Integer strOD,Integer strOM,Integer strOY,Integer intMax,Integer intMin,Integer intQuantity,
//            String strCategory,String strDD,String strLOD,String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
//            String strarea,String strpost_code,String strtown,String strcountry){
//        Product newProduct=new Product();
//        newProduct.Edit(strID, strName, strP,  strOD, strOM, strOY, intMax, intMin, intQuantity, strCategory, strDD, strLOD,
//                strname, strDN, strPN, strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
//        newProduct.SaveToFile();
//    }
    
//    public boolean isProduct(String strID){
//        boolean isFound=false;
//         File Location=new File("File_Location.txt");
//        String EditProduct;
//        FileReader reader;
//        System.out.println("File_Location.txt");
//        try{
//            reader=new FileReader(Location);
//            BufferedReader bin=new BufferedReader(reader);
//            while((EditProduct=bin.readLine())!=null){
//                System.out.println("File_Location.txt");
//                isFound=EditInformation(EditProduct,strID);
//        }
//            bin.close();
//            bin=null;
//    }catch (IOException ioe){
//    }
//        return isFound;
//    }
//    public boolean EditInformation(String EP,String strid){
//        boolean isFound=false;
//        String record=null;
//        FileReader reader;
//        File ProductFile=new File(EP);
//        try{
//            reader=new FileReader(ProductFile);
//            BufferedReader bin=new BufferedReader(reader);
//            while((record=bin.readLine())!=null){
//                if(strid.contentEquals(record)){
//                    isFound=true;
//                }
//                System.out.println("Product Information");
//            }
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            }
//        return isFound;
//    }

    public void Display(javax.swing.JTextArea jProductTextArea, int index){
        jProductTextArea.setText("");
        getProduct(index).Display(jProductTextArea);         
    }
    
     public DefaultListModel List(DefaultListModel model){
        for(int i=0;i<theProducts.size();i++){
            model.addElement(theProducts.get(i).getName());
        }
        return model;
    }
     
    
//     public void addAccount(String Location){
//         if(Location.contains("Current")){
//             CurrentAccount CA=new CurrentAccount();
//             CA.LoadFromFile(Location);
//             Customer C=getClient(CA.getCustomer().getName());
//             if(C!=null){
//                 C.setCurrentAccount(CA);
//                 CA.setCustomer(C);
//                 AccountList.add(CA);
//             }
//         }
     public void AddProduct(String Location){
         Product P=null;
         if(Location.contains("Food")){
//             FoodProduct FP=new FoodProduct();
//             FP.LoadFromFile(Location);
//             theProducts.add(FP);
             System.out.println("Food");
             P=new FoodProduct();
         }
         if(Location.contains("Electrical")){
//             ElectricalProduct EP=new ElectricalProduct();
//             EP.LoadFromFile(Location);
//             theProducts.add(EP);
             System.out.println("Electrical");
            P=new ElectricalProduct();
         }
         if(Location.contains("Crockery")){
//             ElectricalProduct EP=new ElectricalProduct();
//             EP.LoadFromFile(Location);
//             theProducts.add(EP);
             System.out.println("Crockery");
             P=new CrockeryProduct();
         }
         theProducts.add(P.LoadFromFile(Location));
     }
     public void LoadLocation(){
//        File Location=new File("File_Location.txt");
        String CurrentProduct;
        FileReader reader;
        System.out.println("load File_Location.txt");
        try{
            reader=new FileReader(File_Location);
            BufferedReader bin=new BufferedReader(reader);
            while((CurrentProduct=bin.readLine())!=null){
                System.out.println("open File_Location.txt   "+CurrentProduct);
                AddProduct(CurrentProduct);
//                LoadFromFile(CurrentProduct);
        }
            bin.close();
            bin=null;
    }catch (IOException ioe){
    }
    }

//    public void LoadProduct(String theCP){
////        String record=null;
////        FileReader reader;
////        File ProductFile=new File(theCP);
//        try{
////            reader=new FileReader(ProductFile);
//            BufferedReader bin=new BufferedReader(new FileReader(theCP));
//            
////            record=bin.readLine();
//                 System.out.println("Load Product Information");
//                Product P=new Product(bin.readLine(),bin.readLine(),Integer.valueOf( bin.readLine()),Integer.valueOf(bin.readLine()),Double.valueOf(bin.readLine()),
//                        bin.readLine(),Integer.valueOf(bin.readLine()),bin.readLine(),bin.readLine(),bin.readLine(),
//                        bin.readLine(),bin.readLine(),bin.readLine(),
//                        bin.readLine(),Integer.valueOf(bin.readLine()),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine());
////                P.Edit(bin.readLine(),bin.readLine(),Integer.valueOf( bin.readLine()),Integer.valueOf(bin.readLine()),Double.valueOf(bin.readLine()),
////                        bin.readLine(),Integer.valueOf(bin.readLine()),bin.readLine(),bin.readLine(),bin.readLine(),
////                        bin.readLine(),bin.readLine(),bin.readLine(),
////                        bin.readLine(),Integer.valueOf(bin.readLine()),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine());
//                theProducts.add(P);
//               
//            
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            }
//    }

    public Product getProduct(int index){
        for(int i=0;i<theProducts.size();i++){
            if(i==index){
                return theProducts.get(i);
            }
        }
        return null;
    }
    public Product getProduct(String name){
        for(int i=0;i<theProducts.size();i++){
            if(theProducts.get(i).getName().equals(name)){
                return theProducts.get(i);
            }
        }
        return null;
    }
    
//    public void Reorder(){
//        for(int i=0;i<theProducts.size();i++){
//            if(theProducts.get(i).isReorder()){
//                ReorderProducts.add(theProducts.get(i));
//            }
//        }
//    }
//    public DefaultListModel ReorderList(DefaultListModel model){
//        for(int i=0;i<ReorderProducts.size();i++){
//            model.addElement(ReorderProducts.get(i).getName());
//        }
//        return model;
//    }
//     public void DisplayReorder(javax.swing.JTextArea jReorderTextArea, int index){
//        jReorderTextArea.setText("");
//        for(int i=0;i<ReorderProducts.size();i++){
//            if(i==index){
//                ReorderProducts.get(i).DisplayReorderProduct(jReorderTextArea);
//            }
//        }
//    }
//    public void DisplayReorder(javax.swing.JTextArea jReorderTextArea, int index2){
//        jReorderTextArea.setText("");
//        for(int i=0;i<theProduct.size();i++){
//            if(i==index2){
//                theProduct.get(i).DisplayReorderProduct(jReorderTextArea);
//            }
//        }
//    }
//    
//    public DefaultListModel ReorderList(DefaultListModel model2){
//        for(int i=0;i<theProduct.size();i++){
//            if(isReorder(i)){
//                model2.addElement(theProduct.get(i).getName());
//            }
//        }
//        return model2;
//    }
//    public boolean isReorder(int j){
//        boolean isReorder=false;
//        int lnum=0;
//         File Location=new File("Location.txt");
//        String ReorderProduct;
//        FileReader reader;
//        System.out.println("open Location.txt");
//        try{
//             reader=new FileReader(Location);
//             System.out.println("File_Location.txt");
//            BufferedReader bin=new BufferedReader(reader);
//            LineNumberReader lnr=new LineNumberReader(bin);
//            while((ReorderProduct=bin.readLine())!=null&&(lnum=lnr.getLineNumber())==j){
//                
//                isReorder=isReorderProduct(ReorderProduct);
//        }
//            bin.close();
//            bin=null;
//    }catch (IOException ioe){
//    }
//        return isReorder;
//    }
//    public boolean isReorderProduct(String RP){
//        boolean isFound=false;
//        Integer min=null;
//        Integer quantity=null;
//        FileReader reader;
//        File ProductFile=new File(RP);
//        try{
//            reader=new FileReader(ProductFile);
//            BufferedReader bin=new BufferedReader(reader);
//            for(int j=0;j<10;j++){
//                bin.readLine();
//            }
//            
//            min=Integer.valueOf(bin.readLine());
//            quantity=Integer.valueOf(bin.readLine());
//            if(quantity<min){
//                isFound=true;
//                
//            }
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            }
//        return isFound;
//    }
    
//    String strID,String strName,String strWeight,Double strP,Integer strED,Integer strEM,
//            Integer strEY,Integer strOD,Integer strOM,Integer strOY,Integer intMax,Integer intMin,Integer intQuantity,
//            String strCategory,String strDD,String strLOD,String strN,String strS,Integer intHN,
//            String strHN,String strA,String strPC,String strT,String strC)
//    public void LoadFromFile(String theCP){
//        String strID=null;
//        String strName=null;
//        String strWeight=null;
//        Double douP=0.;
//        Integer intED=0;
//        Integer intEM=0;
//        Integer intEY=0;
//        Integer intOD=0;
//        Integer intOM=0;
//        Integer intOY=0;
//         String record=null;
//        FileReader reader;
//        File ProductFile=new File(theCP);
//        try{
//            reader=new FileReader(ProductFile);
//            BufferedReader bin=new BufferedReader(reader);
//            while((record=bin.readLine())!=null){
//                strID=record;
//                strName=bin.readLine();
//                strWeight=bin.readLine();
//                douP=Double.valueOf(bin.readLine());
//                intED=Integer.valueOf(bin.readLine());
//                intEM=Integer.valueOf(bin.readLine());
//                intEY=Integer.valueOf(bin.readLine());
//                intOD=Integer.valueOf(bin.readLine());
//                intOM=Integer.valueOf(bin.readLine());
//                intOY=Integer.valueOf(bin.readLine());
//            }
//            Product P=new Product();
//            P.Edit(strID, strName, strWeight, douP, intED, intEM, intEY, intOD, intOM, intOY);
//            theProduct.add(P);
//            System.out.println("Load Information");
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            }
//    }
    
  
        
        
        
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
