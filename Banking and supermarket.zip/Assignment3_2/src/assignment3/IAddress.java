/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author aaa
 */
public class IAddress {
//    private String Name;
    private String Street;
    private Integer HouseNo;
    private String HouseName;
    private String Area;
    private String PostCode;
    private String Town;
    private String Country;
    
    public IAddress(){
        Edit("",0,"","","","","");
    }
    
    public IAddress(String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry){
    Edit(strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
}
    
    public void Display(javax.swing.JTextArea jAddressTextArea){
        jAddressTextArea.setLineWrap(true);
        jAddressTextArea.append("Street: "+Street+"\nHouse_No: "+HouseNo+"\nHouse_Name: "+HouseName+"\nArea: "+Area+
        "\nPostCode: "+PostCode+"\nTown: "+Town+"\nCountry: "+Country+"\n\n");
    }
    
//    public String ToString(){
//     String address=("Street: "+Street+"\nHouse_No: "+HouseNo+"\nHouse_Name: "+HouseName+"\nArea: "+Area+
//        "\nPostCode: "+PostCode+"\nTown: "+Town+"\nCountry: "+Country+"\n\n");
//     return address;
//    }
    public String getString(){
        return String.format(Street+"\n"+HouseNo+"\n"+HouseName+"\n"+Area+
        "\n"+PostCode+"\n"+Town+"\n"+Country+"\n");
    }
    
    public void Edit(String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry){
//        this.Name=strname;
        this.Street=strstreet;
        this.HouseNo=inthouse_no;
        this.HouseName=strhouse_name;
        this.Area=strarea;
        this.PostCode=strpost_code;
        this.Town=strtown;
        this.Country=strcountry;
    }
    
//    public void SaveToFile(File ProductAddress){
//        FileWriter writer;
//        try{
//            writer=new FileWriter(ProductAddress,true);
//            writer.write(Street+System.getProperty("line.separator"));
//            writer.write(HouseNo+System.getProperty("line.separator"));
//            writer.write(HouseName+System.getProperty("line.separator"));
//            writer.write(Area+System.getProperty("line.separator"));
//            writer.write(PostCode+System.getProperty("line.separator"));
//            writer.write(Town+System.getProperty("line.separator"));
//            writer.write(Country+System.getProperty("line.separator"));
//            writer.flush();
//            writer.close();
//            writer=null;
//        }catch(IOException ioe){
//            
//        }
//    }
    
//    public String getStreet(){
//        return Street;
//    }
//    public Integer getHouseNo(){
//        return HouseNo;
//    }
//    public String getHouseName(){
//        return HouseName;
//    }
//    public String getArea(){
//        return Area;
//    }
//    public String getPostCode(){
//        return PostCode;
//    }
//    public String getTown(){
//        return Town;
//    }
//    public String getCountry(){
//        return Country;
//    }
}
