/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author aaa
 */
public class User {
    private String FirstName;
    private String Surname;
    private String Password;
    private String Role;
    private File UserFile;
    
    private File WishListFile;
    private WishList theWishList;
    
    public User(){
        Edit("","","","");
     
    }
    public User(String strFN,String strSN,String strP,String strR){
        Edit(strFN,strSN,strP,strR);
    }
    public User(User U){
        Edit(U.getFirstName(),U.getSurname(),U.getPassword(),U.getRole());
        theWishList = new WishList();
    }
//    public User(WishList src){
//        this.theWishList=src;
//    }
    
    public void Edit(String strFN,String strSN,String strP,String strR){
        this.FirstName=strFN;
        this.Surname=strSN;
        this.Password=strP;
        this.Role=strR;
    }
    
     public String getFirstName(){
        return FirstName;
    }
    public String getSurname(){
        return Surname;
    }
    public String getPassword(){
        return Password;
    }
    public String getRole(){
        return Role;
    }
    public String getFullName(){
        String FullName=FirstName+Surname;
        return FullName;
    }
    public void setFullName(String strFirstName,String strSurname){
        FirstName=strFirstName;
        Surname=strSurname;
    }
   
    
    public String getString(){
        return String.format(FirstName+"\n"+Surname+"\n"+Password+"\n"+Role+"\n");
    }
    
    public File CreateDirectory(){
        File folder=new File("UserFolder");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir()){
                System.out.println("UserFolder has been created");
            }
            else{
                System.out.println("Failed to create Userfolder");
            }
        }
        return folder;
    }
    public File SaveToFile(){
        UserFile=new File(CreateDirectory()+"/"+this.getFullName()+"-load.txt");
        FileWriter writer;
        try{
            writer=new FileWriter(UserFile,false);
            writer.write(getString()+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
            System.out.println("Save User");
        }catch(IOException ioe){
            
        }
        return UserFile;
    }
    
    public User LoadFromFile(String theUser){
       try{
           BufferedReader bin=new BufferedReader(new FileReader(theUser));
           Edit(bin.readLine(),bin.readLine(),bin.readLine(),bin.readLine());
           bin.close();
           bin=null;
           return this;
       }catch(IOException ioe){
           
       }
       return null;
    }
    
    public void setWishList(WishList src){
        theWishList=src;
    }
    public WishList getWishList(){
        return theWishList;
    }
    public void LoadWishListFile(String UserName){
        File folder=new File("WishList_Folder");
        folder.mkdir();
       
        WishListFile=new File(folder+"/"+UserName+"_load.txt");
        theWishList.LoadFromFile(WishListFile);
        System.out.println(WishListFile);
//        return WishListFile;
    }
}


