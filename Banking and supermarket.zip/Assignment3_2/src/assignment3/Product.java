/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Date;
import javax.swing.JTextArea;

/**
 *
 * @author aaa
 */
public abstract class Product {
    
    protected String ID;
    protected String Name;
    protected Integer Max;
    protected Integer Min;
    protected Double PricewithoutVAT;
    protected Double PricewithVAT;
    protected String EstimatedOrderDate;
    protected Integer QuantityInStock;
    protected String Category;
    protected String DeliveryDate;
    protected String LastOrderDate;
//    protected String Type;
    
   protected Integer NumberOfItem;
   
    
//   protected Double Pay;
    
    
    
        
//    private String Information;
   
//    private File ProductFile;
    
    protected Supplier theSupplier;
//    String Info_array[]={ID,Name,Weight,String.valueOf(PricewithoutVAT),String.valueOf(Eday),String.valueOf(Emonth),
//        String.valueOf(Eyear),String.valueOf(Oday),String.valueOf(Omonth),String.valueOf(Oyear) };
   
    
    public Product(){
        theSupplier=new Supplier();
        PricewithVAT=0.;
        Edit("","",0,0,0.,"",0,"","","");
        NumberOfItem=0;
    }
    
    public Product(String strID,String strName,Integer intMax,Integer intMin,Double douPriceWithoutVAT,String strEstimate,Integer intQuantityInStock,
            String strCategory,String strDD,String strLOD,String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry){
        Edit(strID, strName, intMax,  intMin, douPriceWithoutVAT, strEstimate, intQuantityInStock, strCategory, strDD, strLOD);
        theSupplier = new Supplier(strname, strDN, strPN, strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
    }
    
    
    
    private double truncate(double x)
    {
        DecimalFormat df=new DecimalFormat("0.##");
        String d=df.format(x);
        Double dbl=new Double(d);
        return dbl.doubleValue();
    }
    
    public void Edit(String strID,String strName,Integer intMax,Integer intMin,Double douPriceWithoutVAT,String strEstimate,Integer intQuantityInStock,
            String strCategory,String strDD,String strLOD){
        this.ID=strID;
        this.Name=strName;
        this.Max=intMax;
        this.Min=intMin;
        this.PricewithoutVAT=douPriceWithoutVAT;
        Double VAT=PricewithoutVAT+PricewithoutVAT*0.1;
        this.PricewithVAT=truncate(VAT);
        this.EstimatedOrderDate=strEstimate;
        
        this.QuantityInStock=intQuantityInStock;
        this.Category=strCategory;
        this.DeliveryDate=strDD;
        this.LastOrderDate=strLOD;
//        this.Type=strType;
    }
    
    public void Edit(String strID,String strName,Integer intMax,Integer intMin,Double douPriceWithoutVAT,String strEstimate,Integer intQuantityInStock,
            String strCategory,String strDD,String strLOD,String strname, String strDN, String strPN, String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry){
        Edit(strID, strName, intMax,  intMin, douPriceWithoutVAT, strEstimate, intQuantityInStock, strCategory, strDD, strLOD);
        theSupplier.Edit(strname, strDN, strPN, strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
    }
    
//        public void Edit(String strID,String strName,Integer intMax,Integer intMin,Double douPriceWithoutVAT,String strEstimate,Integer intQuantityInStock,
//            String strCategory,String strDD,String strLOD,Supplier theSupplier){
//        Edit(strID, strName, intMax,  intMin, douPriceWithoutVAT, strEstimate, intQuantityInStock, strCategory, strDD, strLOD);
//        this.theSupplier = theSupplier;
//    }
    

     
    
    public void Display(JTextArea jProduct){
        jProduct.setText("");
        jProduct.setLineWrap(true);
     
        jProduct.append("Product ID: "+ID+"\nProduct Name: "+Name+"\nPrice without VAT: "+PricewithoutVAT+"\nPrice with VAT: "+PricewithVAT+"\nEstimated Date to order: "+EstimatedOrderDate+
                "\nCategory: "+Category+"\nLast Order Date: "+LastOrderDate+"\n");
        theSupplier.Display(jProduct);
    }
    
    
    
    public String getName(){
        return Name;
    }
    public void setName(String strName){
        this.Name=strName;
    }
    public Integer getMin(){
        return Min;
    }
    public Integer getQuantiry(){
        return QuantityInStock;
    }
    public String getString(){
        return String.format(ID+"\n"+Name+"\n"+Max+"\n"+Min+"\n"+PricewithoutVAT+"\n"+EstimatedOrderDate+"\n"+QuantityInStock+"\n"
        +Category+"\n"+DeliveryDate+"\n"+LastOrderDate+"\n"+theSupplier.getString());
    }
    
    
//    public Supplier getSupplier(){
//        return theSupplier;
//    }
//    
    public File CreateFolder(){
        File folder=new File("Products");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir())
            {
                System.out.println("The folder is created");
            }
            else
            {
                System.out.println("Failed to create the folder");
            }
        }
        return folder;
    }
    public abstract File SaveToFile();
    public abstract Product LoadFromFile(String p);
//    public File SaveToFile(){
//        
//        ProductFile=new File(CreateFolder()+"/"+this.getName()+"_load.txt");
//        FileWriter writer;
//        try{
//            writer=new FileWriter(ProductFile,false);
//            
//            writer.write(getString()+System.getProperty("line.separator"));
//            writer.flush();
//            writer.close();
//            writer=null;
//        }catch(IOException ioe){
//        }
//        System.out.println("Save Product");
//        return ProductFile;
//        
//    }
    
//   public boolean isReorder(){
//       boolean isReorder=false;
//       if(QuantityInStock<Min){
//           isReorder=true;
//       }
//       System.out.println("isReorder");
//       return isReorder;
//       
//   }
    
    //    public boolean Reorder(){
//        boolean isReorder=false;
//        if(Quantity<Amount){
//            isReorder=true;
//        }
//        return isReorder;
//    }
    
    public void DisplayReorderProduct(JTextArea jReorder){
        jReorder.setText("");
        jReorder.setLineWrap(true);
        int Amount=Max-QuantityInStock;
        jReorder.append("Product Name: "+Name+"\nReorder Amount: "+Amount+"\nProduct Category: "+Category+
                "\nDelivery Date: "+DeliveryDate+"\nDate of Last Order: "+LastOrderDate+"\n");
        theSupplier.Display(jReorder);
        System.out.println("DisplayReorderProduct");
    }
    
//    public void LoadFromFile(String CurrentProduct){
//        String record=null;
//        FileReader reader;
//        try{
//            reader=new FileReader(CurrentProduct);
//            BufferedReader bin=new BufferedReader(reader);
//            for(int i=0;i<Info_array.length;i++){
//                record=bin.readLine();
//                Info_array[i]=record;
//            }
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            
//        }
//    }
    
    public void setNumberOfItem(int N){
        this.NumberOfItem=N;
    }
    public Integer getNumberOfItem(){
        return NumberOfItem;
    }
    public Double getPrice(){
        return PricewithVAT;
    }
    
}
