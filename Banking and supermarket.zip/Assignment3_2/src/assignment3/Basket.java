/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JTextArea;

/**
 *
 * @author ee13yyl
 */
public class Basket extends ProductList{
    ArrayList<Product> Cart;
//    private User theUser;
    private File folder;
    
    public Basket(){
        super();
        Cart=new ArrayList<Product>();
        folder=new File("Basket");
    }
    
    public void Add(int index,int Number){
        Cart.add(getProduct(index));
        getProduct(index).setNumberOfItem(Number);
        
    }
    
    public DefaultListModel BasketList(DefaultListModel model){
        for(int i=0;i<Cart.size();i++){
            model.addElement(Cart.get(i).getName());
        }
        return model;
    }
     public void Display(javax.swing.JTextArea jta, int index){
        jta.setText("");
        for(int i=0;i<Cart.size();i++){
            if(i==index){
                Cart.get(i).Display(jta);
                jta.append("\nThe number of item: "+Cart.get(i).getNumberOfItem());
            }
        }
    }
     public void AddFromWishList(String name,int N){
         Cart.add(getProduct(name));
         getProduct(name).setNumberOfItem(N);
         System.out.println("Add to Basket");
     }
     
     public void Delete(int index){
        Cart.remove(Cart.get(index));
     }
     
     public Product SelectedItem(int index){
         for(int i=0;i<Cart.size();i++){
             if(i==index){
                 return Cart.get(i);
             }
         }
         return null;
     }
     
     public void ChangeNumber(String name,int N){
         getProduct(name).setNumberOfItem(N);
         System.out.println(N);
     }
     private double truncate(double x)
    {
        DecimalFormat df=new DecimalFormat("0.##");
        String d=df.format(x);
        Double dbl=new Double(d);
        return dbl.doubleValue();
    }
     
     public double TotalPrice(){
         double price=0;
         for(int i=0;i<Cart.size();i++){
             price=price+truncate(Cart.get(i).getPrice()*Cart.get(i).getNumberOfItem());
         }
         return price;
     }
     public void DisplayTotalPrice(JTextArea jta){
         jta.setText("");
         jta.append("The total price: "+TotalPrice());
     }

}
