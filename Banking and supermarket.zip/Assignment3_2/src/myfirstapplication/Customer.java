/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.JTextArea;

/**
 *
 * @author aaa
 */
public class Customer {
    
    private String FirstName;
    private String Surname;
//    private Date DOB;
    private Integer Day;
    private Integer Month;
    private Integer Year;
    
    private IAddress HomeAddress;
//    private Account CustomerAccount;
//    private CurrentAccount theCurrentAccount;
//    private SavingAccount theSavingAccount;
//    private ISAAccount theISAAccount;
//    ArrayList<SavingAccount> theSavingAccounts;
    ArrayList<Account> theAccounts;
//    ArrayList<String> Account_Location;
    private File AccountLocation;
    private File CustomerFile;
//    private File CustomerLocation;
    
    public Customer(){
        HomeAddress=new IAddress();
//        DOB=new Date(01,01,1900);
        Edit("","",01,01,1900);
//        Day=DOB.getDay();
//        Month=DOB.getMonth();
//        Year=DOB.getYear();
       
//        CustomerLocation=new File("Customer_File_Location.txt");
//        CustomerAccount=new Account();
//        theSavingAccounts=new ArrayList<SavingAccount>();
        theAccounts=new ArrayList<Account>();
//        Account_Location=new ArrayList<String>();
//        LoadAccountLocation();
    }
    
    public Customer(Customer src){
        Edit(src.getFirstName(),src.getSurname(),src.getDay(),src.getMonth(),src.getYear());
        this.HomeAddress=src.getAddress();
    }
    public Customer(String strFirstName,String strSurname,Integer intDay,Integer intMonth,Integer intYear){
        Edit(strFirstName,strSurname,intDay,intMonth,intYear);
        
    }
    
    public String getFirstName(){
        return FirstName;
    }
    public String getSurname(){
        return Surname;
    }
     
    public Integer getDay(){
        return Day;
    }
    public Integer getMonth(){
        return Month;
    }
    public Integer getYear(){
        return Year;
    }
    
    public String getName(){
        String FullName=FirstName+Surname;
        return FullName;
    }
    public void setName(String strFirstName,String strSurname){
        FirstName=strFirstName;
        Surname=strSurname;
    }
    
    public void Edit(String strFirstName,String strSurname,Integer intDay,Integer intMonth,Integer intYear){
        this.FirstName=strFirstName;
        this.Surname=strSurname;
        this.Day=intDay;
        this.Month=intMonth;
        this.Year=intYear;
//        DOB=new Date(Day,Month,Year);
//        this.DOB.setDate(Day);
//        this.DOB.setMonth(Month);
//        this.DOB.setYear(Year);
        
    }
    
    public void EditCustomerDetail(String strFirstName,String strSurname,Integer intDay,Integer intMonth,Integer intYear,
            String strN,String strS,Integer intHN,
            String strHN,String strA,String strPC,String strT,String strC){
//        Account ClientAccount=new Account();
        Edit(strFirstName,strSurname,intDay,intMonth,intYear);
//        ClientAccount.Edit(strSC, intAN, douBalance, strNOB);
        HomeAddress.Edit(strN, strS, intHN, strHN, strA,strPC, strT, strC);
    }
    

    
     public void Display(javax.swing.JTextArea jCustomerTextArea){
        Display2(jCustomerTextArea);
        jCustomerTextArea.append(HomeAddress.ToString());
//        HomeAddress.Display(jCustomerTextArea);
       
    }
     
     public void Display2(javax.swing.JTextArea jCustomerTextArea){
         jCustomerTextArea.setText("");
        jCustomerTextArea.setLineWrap(true);
        jCustomerTextArea.append("FirstName: "+FirstName+"\nSurname: "+Surname+"\nDate of Birth: "+Day+"/"+Month+"/"+Year+"\n");
     }
     
//     public void SearchCustomerDisplay(javax.swing.JTextArea jta){
//         Display(jta);
////         jta.append(HomeAddress.ToString());
//     }
    
    public File SaveCustomer(){
        File folder=new File("Customers.txt");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir()){
                System.out.println("Folder has been created");
            }
            else{
                System.out.println("Failed to create folder");
        }
        }
        CustomerFile=new File(folder+"/"+getFirstName()+"-load.txt");
        FileWriter writer;
        try{
            writer=new FileWriter(CustomerFile,false);
            writer.write(FirstName+System.getProperty("line.separator"));
            writer.write(Surname+System.getProperty("line.separator"));
            writer.write(Day+System.getProperty("line.separator"));
            writer.write(Month+System.getProperty("line.separator"));
            writer.write(Year+System.getProperty("line.separator"));
            writer.write(HomeAddress.getName()+System.getProperty("line.separator"));
            writer.write(HomeAddress.getStreet()+System.getProperty("line.separator"));
            writer.write(HomeAddress.getHouseNo()+System.getProperty("line.separator"));
            writer.write(HomeAddress.getHouseName()+System.getProperty("line.separator"));
            writer.write(HomeAddress.getArea()+System.getProperty("line.separator"));
            writer.write(HomeAddress.getPostCode()+System.getProperty("line.separator"));
            writer.write(HomeAddress.getTown()+System.getProperty("line.separator"));
            writer.write(HomeAddress.getCountry()+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
        }catch(IOException ioe){
            
    }
//        try{
//            writer=new FileWriter(CustomerLocation,false);
//            writer.write(Customers+System.getProperty("line.separator"));
//            writer.flush();
//            writer.close();
//            writer=null;
//        }catch(IOException ioe){
//            
//        }
//        CustomerAccount.SaveToFile();
        System.out.println("Save new Customer");
        return CustomerFile;
    }
    
    
    public IAddress getAddress(){
        return HomeAddress;
        
    }
   
    
//    public Account getAccount(int index){
//        for(int i=0;i<theAccounts.size();i++){
//            if(i==index){
//                return theAccounts.get(i);
//            }
//        }
//        return null;
//    }
    public void setAccount(Account a){
        theAccounts.add(a);
    }
    public void DisplayAccount(JTextArea jta){
        for(int i=0;i<theAccounts.size();i++){
            theAccounts.get(i).Display(jta);
        }
    }
//    public void CreateAccount(Account A){
//        theAccounts.add(A);
//        Account_Location.add(String.valueOf(A.SaveToFile()));
////        A.setCustomer(this);
//        A.SaveToFile();
//        SaveAccountLocation();
//        System.out.println("Account is created.");
//    }
//    
//    public DefaultListModel AccountList(DefaultListModel Model){
//        for(int i=0;i<theAccounts.size();i++){
//            Model.addElement(theAccounts.get(i).getSortCode());
//        }
//        return Model;
//    }
    
//    public void addAccount(String Location){
//        Account A=null;
//         if(Location.contains("Current")){
//             A=new CurrentAccount();
//         }
//         if(Location.contains("Saving")){
//             A=new SavingAccount();
//         }
//         if(Location.contains("ISA")){
//             A=new ISAAccount();
//         }
////         A=A.LoadFromFile(Location);
//         System.out.println("Load a type of account "+A);
//         Customer C=getClient(A.LoadFromFile(Location).getCustomer().getName());
//             if(C!=null){
////                 A.setCustomer(C);
//                 theAccounts.add(A.LoadFromFile(Location));
//             }
//     }
//    public Customer getClient(String fullname){
//        if(getName().equals(fullname)){
//            return this;
//        }
//        return null;
//    }
//    public void LoadAccountLocation(){
//        AccountLocation=new File("Account_File_Location.txt");
//        String theAccountLine;
//        FileReader reader;
//        System.out.println("Load Account Location File");
//        try{
//            reader=new FileReader(AccountLocation);
//            BufferedReader bin=new BufferedReader(reader);
//            while((theAccountLine=bin.readLine())!=null){
//                System.out.println("load account file");
//               addAccount(theAccountLine);
//            }
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            
//        }
//    }
    
    
    
//    
//    
//    public void DisplayAccount(JTextArea jta,int index){
//        getAccount(index).Display(jta);
//    }
//    public void DisplayCustomer(JTextArea jta,int index){
//        getAccount(index).getCustomer().Display2(jta);
//    }
//     public Customer getClient(String fullname){
//        for(int i=0;i<theClients.size();i++){
//            if(theClients.get(i).getName().equals(fullname)){
//                return theClients.get(i);
//            }
//        }
//        return null;
//    }
    
    
}


//    public Account getAccount(){
//        return CustomerAccount;
//    }
    
//    public void setAccount(Account a){
//        CustomerAccount=new Account();
//        CustomerAccount.setAccount(a.getSortCode(), a.getAccountNo(), a.getBalance(), a.getNOB(), a.getFirstName(), a.getSurname());
//    }
//    public CurrentAccount getCurrentAccount(){
//        return theCurrentAccount;
//    }
//    public void setCurrentAccount(CurrentAccount CA){
//        theCurrentAccount=new CurrentAccount(CA);
//    }
//    public SavingAccount getSavingAccount(){
//        for(int i=0;i<theSavingAccounts.size();i++){
//            return theSavingAccounts.get(i);
//        }
//        return null;
//    }
//    public void DisplaySavingAccount(JTextArea jta){
//        for(int i=0;i<theSavingAccounts.size();i++){
//            theSavingAccounts.get(i).Display(jta);
//        }
//    }
//    public void setSavingAccount(SavingAccount SA){
//        theSavingAccounts.add(SA);
//    }    
//    public ISAAccount getISAAccount(){
//        return theISAAccount;
//    }
//   
//    public void setISAAccount(ISAAccount IS){
//        theISAAccount=new ISAAccount(IS);
//    }
//    public void NewAccount(String strSC,Integer intAN,Double douBalance,String strNOB){
//
//        CustomerAccount.setAccount(strSC, intAN,douBalance,strNOB);
//    }
//    
    

