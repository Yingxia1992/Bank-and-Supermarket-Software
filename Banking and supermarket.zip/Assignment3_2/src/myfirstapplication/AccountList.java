/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JTextArea;

/**
 *
 * @author aaa
 */
public class AccountList {
    ArrayList<Account> theAccounts;
    ArrayList<String> Account_Location;
    private CustomerList ClientList;
    private File AccountLocation;
    
    public AccountList(){
        theAccounts=new ArrayList<Account>();
         Account_Location=new ArrayList<String>();
         ClientList = new CustomerList();
          LoadAccountLocation();
    }
    
    public void CreateAccount(Account A,int index){
        theAccounts.add(A);
        Account_Location.add(String.valueOf(A.SaveToFile()));
//        A.setCustomer(this);
        Customer C=ClientList.getClient(index);
        C.setAccount(A);
        A.setCustomer(C);
        A.SaveToFile();
        SaveAccountLocation();
        System.out.println("Account is created.");
    }
    
    public void SaveAccountLocation(){
        FileWriter writer;
        try{
            writer=new FileWriter(AccountLocation,true);
            for(int i=0;i<Account_Location.size();i++){
                writer.write(Account_Location.get(i)+System.getProperty("line.separator"));
            }
            writer.flush();
            writer.close();
            writer=null;
           
        }catch(IOException ioe){
            
        }
        
    }
    public void addAccount(String Location){
        Account A=null;
         if(Location.contains("Current")){
             A=new CurrentAccount();
         }
         if(Location.contains("Saving")){
             A=new SavingAccount();
         }
         if(Location.contains("ISA")){
             A=new ISAAccount();
         }
//         A=A.LoadFromFile(Location);
         A.LoadFromFile(Location);
         System.out.println("Load a type of account "+A);
//         Customer C=ClientList.getClient(A.LoadFromFile(Location).getCustomer().getName());
          Customer C=ClientList.getClient(A.getFirstName()+A.getSurname());
             if(C!=null){
                 A.setCustomer(C);
                 C.setAccount(A);
                 theAccounts.add(A.LoadFromFile(Location));
             }
     }
     
    public void LoadAccountLocation(){
        AccountLocation=new File("Account_File_Location.txt");
        String theAccountLine;
        FileReader reader;
        System.out.println("Load Account Location File");
        try{
            reader=new FileReader(AccountLocation);
            BufferedReader bin=new BufferedReader(reader);
            while((theAccountLine=bin.readLine())!=null){
                System.out.println("load account file");
               addAccount(theAccountLine);
            }
            bin.close();
            bin=null;
        }catch(IOException ioe){
            
        }
    }
    public Account getAccount(int index){
        for(int i=0;i<theAccounts.size();i++){
            if(i==index){
                return theAccounts.get(i);
            }
        }
        return null;
    }
    public DefaultListModel AccountList(DefaultListModel Model){
        for(int i=0;i<theAccounts.size();i++){
            Model.addElement(theAccounts.get(i).getSortCode());
        }
        return Model;
    }
    public void DisplayAccount(JTextArea jta,int index){
        jta.setText("");
//        for(int i=0;i<AccountList.size();i++){
//             AccountList.get(i).Display(jta);
//        }
       
        getAccount(index).Display(jta);
    }
    public void DisplayCustomer(javax.swing.JTextArea jClientTextArea, int index){
        jClientTextArea.setText("");        
//        getAccount(index).Display(jClientTextArea);
        getAccount(index).getCustomer().Display2(jClientTextArea);
//        jAccountTextArea.append(ClientList.getClient(jAccountList.getSelectedIndex()).getAddress().ToString());
//        for(int i=0;i<theClients.size();i++){
//             theClients.get(i).DisplayCustomer(jClientTextArea, index);
//        }
    }
    public void DisplayAccount2(javax.swing.JTextArea jAccountTextArea, int index){
        jAccountTextArea.setText("");    
        ClientList.getClient(index).Display(jAccountTextArea);
        ClientList.getClient(index).DisplayAccount(jAccountTextArea);
//        getClient(index).getCurrentAccount().Display(jAccountTextArea);
//        getClient(index).DisplaySavingAccount(jAccountTextArea);
//        getClient(index).getISAAccount().Display(jAccountTextArea);
    }
    public void Pay(String SortCode,int AccountNo,double payment){
        for(int i=0;i<theAccounts.size();i++){
            if(theAccounts.get(i).getSortCode().equals(SortCode)){
                if(theAccounts.get(i).getAccountNo().equals(AccountNo)){
                    theAccounts.get(i).Withdrawal(payment);
                }
            }
        }
//        return null;
    }
}
