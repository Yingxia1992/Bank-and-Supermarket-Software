/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author aaa
 */
public class CurrentAccount extends Account{
    
    private Double Overdraft;
    private String Conditions;
    private Double AvailableBalance;
    
//    private Customer theClient;
    private File CurrentAccountFile;
    
    public CurrentAccount(){
        super();
       Edit(100.,"",0.); 
    }
    public CurrentAccount(String strSC,Integer intAN,Double douBalance,String strNOB,
            String strFN,String strSN,Double douOD,String strConditions,Double douAB){
        super(strSC,intAN,douBalance,strNOB,strFN,strSN);
        Edit(douOD,strConditions,douAB);
    }
    public CurrentAccount(CurrentAccount src){
        setCurrentAccount(src.getSortCode(),src.getAccountNo(),src.getBalance(),src.getNOB(),src.getFirstName(),src.getSurname(),
                src.getOverdraft(),src.getConditions(),src.getAvailableBalance());
    }
    
    public void Edit(Double douOD,String strConditions,Double douAB){
        this.Overdraft=douOD;
        this.Conditions=strConditions;
        this.AvailableBalance=douAB;
    }
    
    public void setCurrentAccount(String strSC,Integer intAN,Double douBalance,String strNOB,
            String strFN,String strSN,Double douOD,String strConditions,Double douAB){
        super.setAccount(strSC, intAN, douBalance, strNOB, strFN, strSN);
        Edit(douOD,strConditions,douAB);
    }

    public File CreateDirectory(){
        File folder=new File(super.CreateDirectory()+"/"+"CurrentAccounts_Folder.txt");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir()){
                System.out.println("AccoutFolder has been created");
            }
            else{
                System.out.println("AccountFailed to create folder");
        }
        }

        return folder;
    }
    
     
    
    public File SaveToFile(){
        CurrentAccountFile=new File(CreateDirectory()+"/"+this.getSortCode()+"-load.txt");
        FileWriter writer;
        try{
            writer=new FileWriter(CurrentAccountFile,false);
            writer.write(getString()+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
            System.out.println("Save CurrentAccount");
        }catch(IOException ioe){
            
        }
        return CurrentAccountFile;
    }
    
    public CurrentAccount LoadFromFile(String theAccount){
        CurrentAccountFile=new File(theAccount);
        FileReader reader;
        System.out.println("Load"+theAccount);
        try{
            reader=new FileReader(CurrentAccountFile);
            BufferedReader bin=new BufferedReader(reader);
            setCurrentAccount(bin.readLine(), Integer.valueOf(bin.readLine()), Double.valueOf(bin.readLine()), 
                        bin.readLine(), FirstName=bin.readLine(),Surname=bin.readLine(),
                    Double.valueOf(bin.readLine()),bin.readLine(),Double.valueOf(bin.readLine()));
//            theClient = new Customer();
//            theClient.setName(FirstName, Surname);
//            System.out.println(theClient.getName());
//            this.setCustomerName(FirstName, Surname);
            bin.close();
            bin=null;
            return this;
        }catch(IOException ioe){
            
        }
        return null;
    }
    
    public void Display(javax.swing.JTextArea jAccountTextArea){
         super.Display(jAccountTextArea);
         jAccountTextArea.append("\n"+"Account Type: Current Account"+"\nOverdraft: "+Overdraft
         +"\nConditions: "+Conditions+"\nAvailable Balance: "+AvailableBalance);
     }
    
    public void Deposit(double Amount){
//        super.Deposit(Amount);
        this.Balance+=Amount;
        SaveToFile();
    }
     public void Withdrawal(double Amount){
//         super.Withdrawal(Amount);
         if(Amount<(Balance+Overdraft)){
        this.Balance=Balance-Amount;
        SaveToFile();
         }
         
    }
    
//    public void setCustomer(Customer C){
//        theClient=new Customer(C);
//    }
//    public Customer getCustomer(){
//        return theClient;
//    }
    public Double getOverdraft(){
        return Overdraft;
    }
    public String getConditions(){
        return Conditions;
    }
    public Double getAvailableBalance(){
   
        return AvailableBalance;
    }
    
    public String getString(){
        return String.format(super.getString()+Overdraft+"\n"+Conditions+"\n"+AvailableBalance);
    }
    public String ToString(){
        String CurrentAccount=("Account Type: Current Account"+"\n"+super.ToString()+"\nOverdraft: "+Overdraft
         +"\nConditions: "+Conditions+"\nAvailable Balance: "+AvailableBalance);
        return CurrentAccount;
    }
}

