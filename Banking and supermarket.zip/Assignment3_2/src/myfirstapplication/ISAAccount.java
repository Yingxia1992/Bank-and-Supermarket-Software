/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author aaa
 */
public class ISAAccount extends Account{
    private Double MaximumLimitPerYear;
    private Double DepositedThisYear;
    private File ISAAccountFile;
//    private Customer theClient;
   
    
    public ISAAccount(){
        super();
        Edit(3250.,0.);
    }
    public ISAAccount(String strSC,Integer intAN,Double douBalance,String strNOB,
            String strFN,String strSN,double max,double douDeposited){
        super(strSC,intAN,douBalance,strNOB,strFN,strSN);
        Edit(max,douDeposited);
    }
    public ISAAccount(ISAAccount src){
        setISAAccount(src.getSortCode(),src.getAccountNo(),src.getBalance(),src.getNOB(),src.getFirstName(),src.getSurname(),
                src.getMax(),src.getDeposited());
    }
    
    public void Edit(double max,double douDeposited){
        this.MaximumLimitPerYear=max;
        this.DepositedThisYear=douDeposited;
    }
    public Double getMax(){
        return MaximumLimitPerYear;
    }
    public Double getDeposited(){
        return DepositedThisYear;
    }
    
    public void setISAAccount(String strSC,Integer intAN,Double douBalance,String strNOB,
            String strFN,String strSN,double max,double douDeposited){
        super.setAccount(strSC, intAN, douBalance, strNOB, strFN, strSN);
        Edit(max,douDeposited);
    }
    
    public String getString(){
        return String.format(super.getString()+MaximumLimitPerYear+"\n"+DepositedThisYear);
    }
    
     public File CreateDirectory(){
        File folder=new File(super.CreateDirectory()+"/"+"ISAAccounts_Folder.txt");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir()){
                System.out.println("ISAAccounts_Folder has been created");
            }
            else{
                System.out.println("Failed to create ISAAccounts_Folder");
        }
        }
        return folder;
    }
    public File SaveToFile(){
        ISAAccountFile=new File(CreateDirectory()+"/"+this.getSortCode()+"-load.txt");
        FileWriter writer;
        try{
            writer=new FileWriter(ISAAccountFile,false);
            writer.write(getString()+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
            System.out.println("Save ISAAccount");
        }catch(IOException ioe){
            
        }
        return ISAAccountFile;
    }
    
    public ISAAccount LoadFromFile(String theAccount){
       ISAAccountFile=new File(theAccount);
        FileReader reader;
        System.out.println("Load"+theAccount);
        try{
            reader=new FileReader(ISAAccountFile);
            BufferedReader bin=new BufferedReader(reader);
            setISAAccount(bin.readLine(), Integer.valueOf(bin.readLine()), Double.valueOf(bin.readLine()), 
                        bin.readLine(), FirstName=bin.readLine(),Surname=bin.readLine(),
                    Double.valueOf(bin.readLine()),Double.valueOf(bin.readLine()));
////            theClient = new Customer();
////            theClient.setName(FirstName, Surname);
//            System.out.println(theClient.getName());
//            this.setCustomerName(FirstName, Surname);
            bin.close();
            bin=null;
            return this;
        }catch(IOException ioe){
            
        }
        return null;
    }
    
//    public void setCustomer(Customer C){
//        theClient=new Customer(C);
//    }
//    public Customer getCustomer(){
//        return theClient;
//    }
    public void Display(javax.swing.JTextArea jAccountTextArea){
         super.Display(jAccountTextArea);
         jAccountTextArea.append("\n"+"Account Type: ISAAccount"+"\nMaximum Limit Per Year: "+MaximumLimitPerYear+"\nDeposited This Year: "+DepositedThisYear);
     }
    public String ToString(){
        String SavingAccount=("Account Type: ISAAccount"+"\n"+super.ToString()+"\nMaximum Limit Per Year: "+MaximumLimitPerYear+"\nDeposited This Year: "+DepositedThisYear);
        return SavingAccount;
    }
    
    public void Deposit(double Amount){
        if(Amount<MaximumLimitPerYear){
            this.Balance+=Amount;
            SaveToFile();
        }
        
    }
     public void Withdrawal(double Amount){
//        for(int i=0;i<1;i++){

            this.Balance=Balance-Amount;
            SaveToFile();
//        }
 
    }
}
