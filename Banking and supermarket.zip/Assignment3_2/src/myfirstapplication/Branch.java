/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author aaa
 */
public class Branch {
    
    private String WorkingHours;
    private String SortCode;
    private String Manager;
    private IAddress theAddress;
    
    private File HeadOffice;
    private File Branches;
    private File FileLocation;
    
    public Branch(){
        Edit("9:00-17:00","00-00-00","");
        theAddress=new IAddress();
        HeadOffice=new File("HeadOffice.txt");
        FileLocation=new File("BranchFile_Location.txt");
    }
    
    public void Display(javax.swing.JTextArea jBranchTextArea){
        jBranchTextArea.setText("");
        jBranchTextArea.setLineWrap(true);
        jBranchTextArea.append("Working_Hours: "+WorkingHours+"\nSortCode: "+SortCode+"\nManager: "+Manager+"\n");
        theAddress.Display(jBranchTextArea);
       
    }
    
    public String getSortCode(){
        return SortCode;
    }
    public void Edit(String strWH,String strSC,String strM){
        this.WorkingHours=strWH;
        this.SortCode=strSC;
        this.Manager=strM;
    }
    public void EditBranchDetail(String strWH,String strSC,String strM,String strN,String strS,Integer intHN,
            String strHN,String strA,String strPC,String strT,String strC){
        Edit(strWH,strSC,strM);
        theAddress.Edit(strN, strS, intHN, strHN, strA,strPC, strT, strC);
    }
    
    public void SaveToFile(){
       
        FileWriter writer;
        try{
            writer=new FileWriter(HeadOffice,true);
            writer.write(WorkingHours+System.getProperty("line.separator"));
            writer.write(SortCode+System.getProperty("line.separator"));
            writer.write(Manager+System.getProperty("line.separator"));
            writer.write(theAddress.getName()+System.getProperty("line.separator"));
            writer.write(theAddress.getStreet()+System.getProperty("line.separator"));
            writer.write(theAddress.getHouseNo()+System.getProperty("line.separator"));
            writer.write(theAddress.getHouseName()+System.getProperty("line.separator"));
            writer.write(theAddress.getArea()+System.getProperty("line.separator"));
            writer.write(theAddress.getPostCode()+System.getProperty("line.separator"));
            writer.write(theAddress.getTown()+System.getProperty("line.separator"));
            writer.write(theAddress.getCountry()+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
        }catch(IOException ioe){
            
        }
    }
    
    public void LoadFromFile(){
        String record;
        FileReader reader;
        System.out.println("load HeadOffice.txt");
        String strWH="";
        String strSC="";
        String strM="";
        String strN="";
        String strS="";
        Integer intHN=0;
        String strHN="";
        String strA="";
        String strPC="";
        String strT="";
        String strC="";
        try{
            reader=new FileReader(HeadOffice);
            BufferedReader bin=new BufferedReader(reader);
            while((record=bin.readLine())!=null){
                strWH=record;
                strSC=bin.readLine();
                strM=bin.readLine();
                strN=bin.readLine();
                strS=bin.readLine();
                intHN=Integer.valueOf(bin.readLine());
                strHN=bin.readLine();
                strA=bin.readLine();
                strPC=bin.readLine();
                strT=bin.readLine();
                strC=bin.readLine();
                
            }
            EditBranchDetail(strWH,strSC,strM,strN,strS,intHN,strHN,strA,strPC,strT,strC);
            System.out.println(WorkingHours);
            System.out.println(theAddress.getCountry());
            bin.close();
            bin=null;
        }catch(IOException ioe){
            
        }
    }
    
    public void SaveBranch(){
        File folder=new File("Branches.txt");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir()){
                System.out.println("Directory is created.");
            }
            else{
                System.out.println("Failed to create directory.");
            }
        }
        Branches=new File(folder+"/"+getSortCode()+"-load.txt");
        FileWriter writer;
        try{
            writer=new FileWriter(Branches,false);
            writer.write(WorkingHours+System.getProperty("line.separator"));
            writer.write(SortCode+System.getProperty("line.separator"));
            writer.write(Manager+System.getProperty("line.separator"));
            writer.write(theAddress.getName()+System.getProperty("line.separator"));
            writer.write(theAddress.getStreet()+System.getProperty("line.separator"));
            writer.write(theAddress.getHouseNo()+System.getProperty("line.separator"));
            writer.write(theAddress.getHouseName()+System.getProperty("line.separator"));
            writer.write(theAddress.getArea()+System.getProperty("line.separator"));
            writer.write(theAddress.getPostCode()+System.getProperty("line.separator"));
            writer.write(theAddress.getTown()+System.getProperty("line.separator"));
            writer.write(theAddress.getCountry()+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
        }catch(IOException ioe){
        }
        try{
            writer=new FileWriter(FileLocation,true);
            writer.write(Branches+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
        }catch(IOException ioe){
            
        }
    }
    
    
}
