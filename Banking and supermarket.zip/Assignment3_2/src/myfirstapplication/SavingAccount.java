/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author aaa
 */
public class SavingAccount extends Account{
    private Double WithdrawLimit;
//    private Customer theClient;
    private File SavingAccountFile;
    
    public SavingAccount(){
        super();
        Edit(200.);
    }
    public SavingAccount(String strSC,Integer intAN,Double douBalance,String strNOB,
            String strFN,String strSN,Double douWithdrawLimit){
        super(strSC,intAN,douBalance,strNOB,strFN,strSN);
        Edit(douWithdrawLimit);
    }
    public SavingAccount(SavingAccount src){
        setSavingAccount(src.getSortCode(),src.getAccountNo(),src.getBalance(),src.getNOB(),src.getFirstName(),src.getSurname(),src.getWithdrawLimit());
    }
    
    public void Edit(Double douWithdrawLimit){
        this.WithdrawLimit=douWithdrawLimit;
    }
    
    public Double getWithdrawLimit(){
        return WithdrawLimit;
    }
    
    public void setSavingAccount(String strSC,Integer intAN,Double douBalance,String strNOB,
            String strFN,String strSN,Double douWithdrawLimit){
        super.setAccount(strSC, intAN, douBalance, strNOB, strFN, strSN);
        Edit(douWithdrawLimit);
    }
    public String getString(){
        return String.format(super.getString()+WithdrawLimit);
    }
    public File CreateDirectory(){
        File folder=new File(super.CreateDirectory()+"/"+"SavingAccounts_Folder.txt");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir()){
                System.out.println("SavingAccounts_Folder has been created");
            }
            else{
                System.out.println("Failed to create SavingAccounts_Folder");
        }
        }
        return folder;
    }
    public File SaveToFile(){
        SavingAccountFile=new File(CreateDirectory()+"/"+this.getSortCode()+"-load.txt");
        FileWriter writer;
        try{
            writer=new FileWriter(SavingAccountFile,false);
            writer.write(getString()+System.getProperty("line.separator"));
            writer.flush();
            writer.close();
            writer=null;
            System.out.println("Save SavingAccount");
        }catch(IOException ioe){
            
        }
        return SavingAccountFile;
    }
    
     public SavingAccount LoadFromFile(String theAccount){
       SavingAccountFile=new File(theAccount);
        FileReader reader;
        System.out.println("Load"+theAccount);
        try{
            reader=new FileReader(SavingAccountFile);
            BufferedReader bin=new BufferedReader(reader);
            setSavingAccount(bin.readLine(), Integer.valueOf(bin.readLine()), Double.valueOf(bin.readLine()), 
                        bin.readLine(), FirstName=bin.readLine(),Surname=bin.readLine(),
                    Double.valueOf(bin.readLine()));
//            theClient = new Customer();
//            theClient.setName(FirstName, Surname);
//            System.out.println(theClient.getName());
//            this.setCustomerName(FirstName, Surname);
            bin.close();
            bin=null;
            return this;
        }catch(IOException ioe){
            
        }
        return null;
    }
     
//    public void setCustomer(Customer C){
//        theClient=new Customer(C);
//    }
//    public Customer getCustomer(){
//        return theClient;
//    }
    
    public void Display(javax.swing.JTextArea jAccountTextArea){
         super.Display(jAccountTextArea);
         jAccountTextArea.append("\n"+"Account Type: Saving Account"+"\nWithdrawLimit: "+WithdrawLimit);
     }
    public String ToString(){
        String SavingAccount=("Account Type: Saving Account"+"\n"+super.ToString()+"\nWithdrawLimit: "+WithdrawLimit);
        return SavingAccount;
    }
    
    public void Deposit(double Amount){
        this.Balance+=Amount;
        SaveToFile();
    }
     public void Withdrawal(double Amount){

         if(Amount<WithdrawLimit){
             this.Balance=Balance-Amount;
             SaveToFile();
         }
         
    }
}
