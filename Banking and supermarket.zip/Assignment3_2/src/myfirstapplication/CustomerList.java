/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextArea;

/**
 *
 * @author aaa
 */
public class CustomerList {
    ArrayList<Customer> theClients;
    ArrayList<String> Directory_Location;
//    ArrayList<CurrentAccount> theCurrentAccounts;
//    ArrayList<String> CurrentAccountsLocation;
//    ArrayList<SavingAccount> theSavingAccounts;
//    ArrayList<String> SavingAccountLocation;
//    ArrayList<Account> AccountList;
//    ArrayList<String> Account_Location;
    
    private File FileLocation;
    private File ClientFile;
//    private File CurrentAccountFile;
//    private File CALocation;
//    private File SALocation;
//    private File AccountFile;
//    private File AccountLocation;
    
    public CustomerList(){
        theClients=new ArrayList<Customer>();
//        AccountList=new ArrayList<Account>();
        Directory_Location=new ArrayList<String>();
//        Account_Location=new ArrayList<String>();
//        theCurrentAccounts=new ArrayList<CurrentAccount>();
//        CurrentAccountsLocation=new ArrayList<String>();
//        theSavingAccounts=new ArrayList<SavingAccount>();
//        SavingAccountLocation=new ArrayList<String>();
        
        LoadFileLocation();
//        LoadCurrentAccountLocation();
//        LoadSavingAccountLocation();
//        LoadAccountLocation();
    }
    
    public void Add(String strFirstName,String strSurname,Integer intDay,Integer intMonth,Integer intYear,
            String strname,String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry){
        Customer newClient=new Customer();
        newClient.EditCustomerDetail(strFirstName, strSurname, intDay, intMonth, intYear,
                strname, strstreet, inthouse_no, strhouse_name, strarea, strpost_code, strtown, strcountry);
//        newClient.NewAccount(strSC, intAN, douBalance, strNOB);
        theClients.add(newClient);
        Directory_Location.add(String.valueOf(newClient.SaveCustomer()));
        newClient.SaveCustomer(); 
        SaveToFile();
    }
    
//    public void CreateAccount(String strSC,Integer intAN,Double douBalance,String strNOB,String strFN,String strSN,int index){
//        Account newAccount=new Account();
//        for(int i=0;i<theClients.size();i++){
//            if(index==i){
//                newAccount.setAccount(strSC, intAN, douBalance, strNOB,strFN,strSN);
//                AccountList.add(newAccount);
//                Account_Location.add(String.valueOf(newAccount.SaveToFile()));
//                Customer C=theClients.get(i);
//                newAccount.setCustomer(C);
//                C.setAccount(newAccount);
//            }
//        }
//        
//        
//        newAccount.SaveToFile();
//        SaveAccountLocation();
//    }
//     public void CreateCurrentAccount(String strSC,Integer intAN,Double douBalance,String strNOB,String strFN,String strSN
//             ,Double douOD,String strConditions,Double douAB,int index){
//        CurrentAccount CA=new CurrentAccount(strSC, intAN, douBalance, strNOB, strFN, strSN, douOD, strConditions, douAB);
//                AccountList.add(CA);
//                Account_Location.add(String.valueOf(CA.SaveToFile()));
//                Customer C=getClient(index);
//                CA.setCustomer(C);
//                C.setCurrentAccount(CA);        
//        CA.SaveToFile();
//        SaveAccountLocation();
//        System.out.println("CurrentAccount is created.");
//     }
//     public void CreateSavingAccount(String strSC,Integer intAN,Double douBalance,String strNOB,
//            String strFN,String strSN,Double douWithdrawLimit,int index){
//        SavingAccount SA=new SavingAccount(strSC, intAN, douBalance, strNOB, strFN, strSN,douWithdrawLimit);
//                AccountList.add(SA);
//                Account_Location.add(String.valueOf(SA.SaveToFile()));
//                Customer C=getClient(index);
//                SA.setCustomer(C);
//                C.setSavingAccount(SA);        
//        SA.SaveToFile();
//        SaveAccountLocation();
//        System.out.println("SavingAccount is created.");
//     }
//    public void CreateISAAccount(String strSC,Integer intAN,Double douBalance,String strNOB,
//            String strFN,String strSN,double max,double douDeposited,int index){
//        ISAAccount IS=new ISAAccount(strSC, intAN, douBalance, strNOB, strFN, strSN,max,douDeposited);
//                AccountList.add(IS);
//                Account_Location.add(String.valueOf(IS.SaveToFile()));
//                Customer C=getClient(index);
//                IS.setCustomer(C);
//                C.setISAAccount(IS);  
//                System.out.println("Customer ISA:"+C.getISAAccount().getFirstName());
//        IS.SaveToFile();
//        SaveAccountLocation();
//        System.out.println("ISAAccount is created.");
//     }
     
//    public void CreateAccount(Account A,int index){
//        AccountList.add(A);
//        Account_Location.add(String.valueOf(A.SaveToFile()));
////        A.setCustomer(this);
//        Customer C=getClient(index);
//        C.setAccount(A);
//        A.setCustomer(C);
//        A.SaveToFile();
//        SaveAccountLocation();
//        System.out.println("Account is created.");
//    }
    
//    public DefaultListModel AccountList(DefaultListModel Model){
//        for(int i=0;i<theAccounts.size();i++){
//            Model.addElement(theAccounts.get(i).getSortCode());
//        }
//        return Model;
//    }
    
//    public void addAccount(String Location){
//        Account A=null;
//         if(Location.contains("Current")){
//             A=new CurrentAccount();
//         }
//         if(Location.contains("Saving")){
//             A=new SavingAccount();
//         }
//         if(Location.contains("ISA")){
//             A=new ISAAccount();
//         }
////         A=A.LoadFromFile(Location);
//         System.out.println("Load a type of account "+A);
//         Customer C=getClient(A.LoadFromFile(Location).getCustomer().getName());
//             if(C!=null){
//                 A.setCustomer(C);
//                 C.setAccount(A);
//                 AccountList.add(A.LoadFromFile(Location));
//             }
//     }
//     
//    public void LoadAccountLocation(){
//        AccountLocation=new File("Account_File_Location.txt");
//        String theAccountLine;
//        FileReader reader;
//        System.out.println("Load Account Location File");
//        try{
//            reader=new FileReader(AccountLocation);
//            BufferedReader bin=new BufferedReader(reader);
//            while((theAccountLine=bin.readLine())!=null){
//                System.out.println("load account file");
//               addAccount(theAccountLine);
//            }
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            
//        }
//    }
    
//     public void SaveAccountLocation(){
//        FileWriter writer;
//        try{
//            writer=new FileWriter(AccountLocation,true);
//            for(int i=0;i<Account_Location.size();i++){
//                writer.write(Account_Location.get(i)+System.getProperty("line.separator"));
//            }
//            writer.flush();
//            writer.close();
//            writer=null;
//           
//        }catch(IOException ioe){
//            
//        }
//        
//    }
    
    
    public void SaveToFile(){
        FileWriter writer;
        try{
            writer=new FileWriter(FileLocation,true);
            for(int i=0;i<Directory_Location.size();i++){
                writer.write(Directory_Location.get(i)+System.getProperty("line.separator"));
            }
            writer.flush();
            writer.close();
            writer=null;
        }catch(IOException ioe){
            
        }
        
    }
    

//    public void SaveAccountLocation(){
//        FileWriter writer;
//        try{
//            writer=new FileWriter(AccountLocation,true);
//            for(int i=0;i<Account_Location.size();i++){
//                writer.write(Account_Location.get(i)+System.getProperty("line.separator"));
//            }
//            writer.flush();
//            writer.close();
//            writer=null;
//           
//        }catch(IOException ioe){
//            
//        }
//        
//    }
    
     public void Remove(String Surname,String FirstName){
         Customer Delete=new Customer();
       for(int i=0;i<theClients.size();i++){
           if(theClients.get(i).getSurname().equals(Surname)&&theClients.get(i).getFirstName().equals(FirstName)){
              Delete=theClients.get(i);
                theClients.remove(Delete);
            
           }
        }
       SaveToFile();
//        FileWriter writer;
//        File DeleteLocation=new File("Customer_File_Location.txt");
//       try{
//            writer=new FileWriter(DeleteLocation,false);
//            for(int j=0;j<Clients.size();j++){
//                 writer.write(Clients.get(j).SaveCustomer()+System.getProperty("line.separator"));
//            }
//           
//            writer.flush();
//            writer.close();
//            writer=null;
//        }catch(IOException ioe){
//            
//        }
       
    }
     
    
    
    public void Display(javax.swing.JTextArea jClientTextArea, int index){
        jClientTextArea.setText("");
        getClient(index).Display(jClientTextArea);
    }    
    
//    public void DisplayAccount(JTextArea jta,int index){
//        jta.setText("");
////        for(int i=0;i<AccountList.size();i++){
////             AccountList.get(i).Display(jta);
////        }
//       
//        getAccount(index).Display(jta);
//    }
//    public void DisplayCustomer(javax.swing.JTextArea jClientTextArea, int index){
//        jClientTextArea.setText("");        
////        getAccount(index).Display(jClientTextArea);
//        getAccount(index).getCustomer().Display2(jClientTextArea);
////        jAccountTextArea.append(ClientList.getClient(jAccountList.getSelectedIndex()).getAddress().ToString());
////        for(int i=0;i<theClients.size();i++){
////             theClients.get(i).DisplayCustomer(jClientTextArea, index);
////        }
//    }
    
//    public void DisplayAccount2(javax.swing.JTextArea jAccountTextArea, int index){
//        jAccountTextArea.setText("");    
//        getClient(index).Display(jAccountTextArea);
//        getClient(index).DisplayAccount(jAccountTextArea);
////        getClient(index).getCurrentAccount().Display(jAccountTextArea);
////        getClient(index).DisplaySavingAccount(jAccountTextArea);
////        getClient(index).getISAAccount().Display(jAccountTextArea);
//    }
//    
    public Customer getClient(int index2){
        for(int i=0;i<theClients.size();i++){
            if(i==index2){
                return theClients.get(i);
            }
        }
        return null;
    }
    public Customer getClient(String fullname){
        for(int i=0;i<theClients.size();i++){
            if(theClients.get(i).getName().equals(fullname)){
                return theClients.get(i);
            }
        }
        return null;
    }
//    public Account getAccount(int index){
//        for(int i=0;i<AccountList.size();i++){
//            if(i==index){
//                return AccountList.get(i);
//            }
//        }
//        return null;
//    }

     
//    public void CurrentAccountDeposit(int index, double amount){        
//        getAccount(index).Deposit(amount);
//    }
//    public void CurrentAccountWithdrawal(int index, double amount){
//        getAccount(index).Withdrawal(amount);
//    }
    
    public DefaultListModel List(DefaultListModel Model){
        for(int i=0;i<theClients.size();i++){
            Model.addElement(theClients.get(i).getFirstName());
        }
        return Model;
    }
//    public DefaultListModel AccountList(DefaultListModel Model){
//        for(int i=0;i<AccountList.size();i++){
//            Model.addElement(AccountList.get(i).getSortCode());
//        }
//        return Model;
//    }
//    public DefaultListModel Account_List(DefaultListModel Model){
//        for(int i=0;i<theClients.size();i++){
//            theClients.get(i).AccountList(Model);
//        }
//        return Model;
//    }

    
    public void LoadFromFile(String theClient){
        ClientFile=new File(theClient);
        String record;
        FileReader reader;
        System.out.println("Load"+theClient);
        String FN=null;
        String SN=null;
        Integer D=0;
        Integer M=0;
        Integer Y=0;
        String strN=null;
        String strS=null;
        Integer intHN=0;
        String strHN=null;
        String strA=null;
        String strPC=null;
        String strT=null;
        String strC=null;
//        String strSortCode=null;
//        Integer intAN=null;
//        Double douBalance=null;
//        String strNOB=null;
        try{
            reader=new FileReader(ClientFile);
            BufferedReader bin=new BufferedReader(reader);
            while((record=bin.readLine())!=null){
                FN=record;
                SN=bin.readLine();
                D=Integer.valueOf(bin.readLine());
                M=Integer.valueOf(bin.readLine());
                Y=Integer.valueOf(bin.readLine());
                strN=bin.readLine();
                strS=bin.readLine();
                intHN=Integer.valueOf(bin.readLine());
                strHN=bin.readLine();
                strA=bin.readLine();
                strPC=bin.readLine();
                strT=bin.readLine();
                strC=bin.readLine();
//                while((bin.readLine())!=null){
//                    Account A =new Account();
//                    A.Edit(bin.readLine(), Integer.valueOf(bin.readLine()),Double.valueOf(bin.readLine()), bin.readLine());
//                    AccountList.add(A);
//                }
////                strSortCode=bin.readLine();
////                intAN=Integer.valueOf(bin.readLine());
////                douBalance=Double.valueOf(bin.readLine());
////                strNOB=bin.readLine();
            }
            Customer C=new Customer();
       
            C.EditCustomerDetail(FN,SN,D,M,Y,strN,strS,intHN,strHN,strA,strPC,strT,strC);
//            C.NewAccount(strC, intAN, douBalance, strNOB);
//            C.LoadAccountLocation();
            theClients.add(C);
            System.out.println("load"+C);
            bin.close();
            bin=null;
        }catch(IOException ioe){
            
        }
    }
    
    public void LoadFileLocation(){
    FileLocation=new File("Customer_File_Location.txt");
    String theClientLine;
    FileReader reader;
    System.out.println("Load Location File");
    try{
        reader=new FileReader(FileLocation);
        BufferedReader bin=new BufferedReader(reader);
        while((theClientLine=bin.readLine())!=null){
            System.out.println("open client file");
            LoadFromFile(theClientLine);
            
        }
        bin.close();
        bin=null;
    }catch(IOException ioe){
        
    }
    }
//     public void LoadAccountLocation(){
//        AccountLocation=new File("Account_File_Location.txt");
//        String theAccountLine;
//        FileReader reader;
//        System.out.println("Load Account Location File");
//        try{
//            reader=new FileReader(AccountLocation);
//            BufferedReader bin=new BufferedReader(reader);
//            while((theAccountLine=bin.readLine())!=null){
//                System.out.println("load account file");
//               addAccount(theAccountLine);
//            }
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            
//        }
//    }
     
     
     
     public Customer Search(Customer src){
        //Customer src=new Customer();
        
        for(int i=0;i<theClients.size();i++){
            if((src.getFirstName()).equalsIgnoreCase(theClients.get(i).getFirstName())){
                if((src.getSurname()).equalsIgnoreCase(theClients.get(i).getSurname())){
//                src=Clients.get(i);
                //jListSearch.setSelectedIndex(i);
                return theClients.get(i);
                }       
            }
        }
        return null;
    }
    public void searchDisplay(Customer c, JTextArea jta){
        c.Display(jta);
//        jta.append(c.getAddress().ToString());
//        jta.append(c.getAccount().ToString());
    }
//    public Customer ClientAccount(String FirstName,String Surname){
//        for(int i=0;i<theClients.size();i++){
//            if(FirstName.equalsIgnoreCase(theClients.get(i).getFirstName())){
//                if(Surname.equalsIgnoreCase(theClients.get(i).getSurname())){
//                    return theClients.get(i);
//                }
//            }
//        }
//        return null;
//    }
//    
    

//     public void LoadCurrentAccountLocation(){
//        CALocation=new File("CurrentAccount_File_Location.txt");
//        String theAccountLine;
//        FileReader reader;
//        System.out.println("Load CurrentAccount Location File");
//        try{
//            reader=new FileReader(CALocation);
//            BufferedReader bin=new BufferedReader(reader);
//            while((theAccountLine=bin.readLine())!=null){
//                System.out.println("load current account file");
//                LoadCurrentAccount(theAccountLine);
//            }    
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            
//        }
//    }
//     public void LoadCurrentAccount(String theCurrentAccount){
//        File AccountFile=new File(theCurrentAccount);
//        FileReader reader;
//        String record;
//        String FirstName;
//        String Surname;
//        System.out.println("Load"+theCurrentAccount);
//        try{
//            reader=new FileReader(AccountFile);
//            BufferedReader bin=new BufferedReader(reader);
//            while((record=bin.readLine())!=null){
//                CurrentAccount CA=new CurrentAccount(record, Integer.valueOf(bin.readLine()), 
//                        Double.valueOf(bin.readLine()), bin.readLine(), FirstName=bin.readLine(),Surname=bin.readLine(),
//                        Double.valueOf(bin.readLine()),bin.readLine(),Double.valueOf(bin.readLine()));
//                if(ClientAccount(FirstName,Surname)!=null){
//                theCurrentAccounts.add(CA);
//                CA.setCustomer(ClientAccount(FirstName,Surname));
//                ClientAccount(FirstName,Surname).setCurrentAccount(CA);
//                }
//            }
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            
//        }
//    }
//     
//      public void LoadSavingAccountLocation(){
//        SALocation=new File("SavingAccount_File_Location.txt");
//        String theAccountLine;
//        FileReader reader;
//        System.out.println("Load SavingAccount Location File");
//        try{
//            reader=new FileReader(SALocation);
//            BufferedReader bin=new BufferedReader(reader);
//            while((theAccountLine=bin.readLine())!=null){
//                System.out.println("load current account file");
//                LoadSavingAccount(theAccountLine);
//            }    
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            
//        }
//    }
//     public void LoadSavingAccount(String theSavingAccount){
//        File AccountFile=new File(theSavingAccount);
//        FileReader reader;
//        String record;
//        String FirstName;
//        String Surname;
//        System.out.println("Load"+theSavingAccount);
//        try{
//            reader=new FileReader(AccountFile);
//            BufferedReader bin=new BufferedReader(reader);
//            while((record=bin.readLine())!=null){
//                SavingAccount SA=new SavingAccount(record, Integer.valueOf(bin.readLine()), 
//                        Double.valueOf(bin.readLine()), bin.readLine(), FirstName=bin.readLine(),Surname=bin.readLine(),
//                        Double.valueOf(bin.readLine()));
//                if(ClientAccount(FirstName,Surname)!=null){
//                theSavingAccounts.add(SA);
//                SA.setCustomer(ClientAccount(FirstName,Surname));
//                ClientAccount(FirstName,Surname).setSavingAccount(SA);
//                }
//            }
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            
//        }
//    }
//    public void LoadAccount(String theAccount){
//        AccountFile=new File(theAccount);
//        FileReader reader;
//        String record;
//        String FirstName;
//        String Surname;
//        System.out.println("Load"+theAccount);
//        try{
//            reader=new FileReader(AccountFile);
//            BufferedReader bin=new BufferedReader(reader);
//            while((record=bin.readLine())!=null){
//                
//                Account A=new Account();
//                A.setAccount(record, Integer.valueOf(bin.readLine()), Double.valueOf(bin.readLine()), bin.readLine(), FirstName=bin.readLine(),Surname=bin.readLine());
//                if(ClientAccount(FirstName,Surname)!=null){
//                AccountList.add(A);
//                A.setCustomer(ClientAccount(FirstName,Surname));
//                ClientAccount(FirstName,Surname).setAccount(A);
//                }
//            }
//            bin.close();
//            bin=null;
//        }catch(IOException ioe){
//            
//        }
//    }
//    
   
   
    
    
}
