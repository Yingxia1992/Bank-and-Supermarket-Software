/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.DefaultListModel;

/**
 *
 * @author aaa
 */
public class BranchList {
    ArrayList<Branch> theBranchs;
//    BranchList SubDepartments;
   // public File Location;
    
    public BranchList(){
        theBranchs=new ArrayList<Branch>();
//        SubDepartments=new BranchList();
        LoadLocation();
        
    }
    
    public void Add(String strWH,String strSC,String strM,String strN,String strS,Integer intHN,
            String strHN,String strA,String strPC,String strT,String strC){
       Branch newbranch=new Branch();
        newbranch=new Branch();
       newbranch.EditBranchDetail(strWH, strSC, strM, strN, strS, intHN, strHN, strA, strPC, strT, strC);
       theBranchs.add(newbranch);
       
       newbranch.SaveBranch();
    }
    
//    public void AddSubDepartments(String strWH,String strSC,String strM,String strN,String strS,Integer intHN,
//            String strHN,String strA,String strPC,String strT,String strC){
//        SubDepartments.Add(strWH, strSC, strM, strN, strS, intHN, strHN, strA, strPC, strT, strC);
//    }
    
    public void Display(javax.swing.JTextArea jtheBranchTextArea, int index){
        jtheBranchTextArea.setText("");
        for(int i=0;i<theBranchs.size();i++)
        {
            if(i==index){
                theBranchs.get(i).Display(jtheBranchTextArea);
            }
        }
    }
    
    public void LoadLocation(){
        File Location=new File("BranchFile_Location.txt");
        String CurrentBranch;
        FileReader reader;
        System.out.println("load File_Location.txt");
        try{
            reader=new FileReader(Location);
            BufferedReader bin=new BufferedReader(reader);
            while((CurrentBranch=bin.readLine())!=null){
                System.out.println("open File_Location.txt");
                LoadBranch(CurrentBranch);
        }
            bin.close();
            bin=null;
    }catch (IOException ioe){
    }
    }
        
    public void LoadBranch(String theCurrentBranch){
        File BranchFile=new File(theCurrentBranch);
        String record;
        FileReader reader;
        System.out.println("load"+theCurrentBranch);
        String strWH=null;
        String strSC=null;
        String strM=null;
        String strN=null;
        String strS=null;
        Integer intHN=0;
        String strHN=null;
        String strA=null;
        String strPC=null;
        String strT=null;
        String strC=null;
        try{
            reader=new FileReader(BranchFile);
            BufferedReader bin=new BufferedReader(reader);
            while((record=bin.readLine())!=null){
                strWH=record;
                strSC=bin.readLine();
                strM=bin.readLine();
                strN=bin.readLine();
                strS=bin.readLine();
                intHN=Integer.valueOf(bin.readLine());
                strHN=bin.readLine();
                strA=bin.readLine();
                strPC=bin.readLine();
                strT=bin.readLine();
                strC=bin.readLine();
                
            }
            Branch B=new Branch();
            B.EditBranchDetail(strWH, strSC, strM, strN, strS, intHN, strHN, strA, strPC, strT, strC);
            theBranchs.add(B);
            System.out.println("load newbranch");
            bin.close();
            bin=null;
        }catch(IOException ioe){
        
    }
    }  
    
    public DefaultListModel List(DefaultListModel model1){
        for(int i=0;i<theBranchs.size();i++){
            model1.addElement(theBranchs.get(i).getSortCode());
        }
        return model1;
    }
    
    
    
}
