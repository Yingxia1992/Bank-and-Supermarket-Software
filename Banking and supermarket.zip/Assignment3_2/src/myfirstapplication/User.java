/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.*;
/**
 *
 * @author aaa
 */
public class User {
    private String name;
    private String role;
    private String password;
    private String filename;
    
    public User(){
    filename=("login.txt");
    role="Bank Employee";
    }
    
    public boolean isRegistered(String newName,String newPassword,String newRole){
    boolean isRegistered;
    name=newName;
    password=newPassword;
    role=newRole;
    FileWriter writer;
    try{
        writer=new FileWriter(filename,true);
        writer.write(name+System.getProperty("line.separator"));
        writer.write(password+System.getProperty("line.separator"));
        writer.write(role+System.getProperty("line separator"));
        isRegistered=true;
        writer.flush();
        writer.close();
        writer=null;
    }
    catch(IOException ioe){
        isRegistered=false;
    }
    return isRegistered;
    }
    
   public boolean isUser(String newName,String newPassword,String newRole){
   name=newName;
   password=newPassword;
   role=newRole;
   boolean isFound=false;
   String record;
   FileReader reader;
   try{
       reader=new FileReader(filename);
       BufferedReader bin=new BufferedReader(reader);
       record=new String();
       while((record=bin.readLine())!=null){
           if(password.contentEquals(record))
            isFound=true;
       }
       bin.close();
       bin=null;
       
   }catch(IOException ioe){
               isFound=false;
   }
       return isFound;
   }
 
   public boolean isManager(){
       if(role.contains("Manager"))
           return true;
       else
           return false;
 
 }
   public boolean isEmployee(){
       if(role.contains("Employee"))
           return true;
       else 
           return false;
   }
   
   public boolean isAdministrator(){
       if(role.contains("Administrator"))
           return true;
       else 
           return false;
   }
   
   public boolean isAdvisor(){
       if(role.contains("Advisor"))
           return true;
       else 
           return false;
   }
   
   public boolean isCustomer(){
       if(role.contains("Customer"))
           return true;
       else 
           return false;
   }
}
