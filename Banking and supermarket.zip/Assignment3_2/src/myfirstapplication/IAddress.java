/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

/**
 *
 * @author aaa
 */
public class IAddress {
    
    private String Name;
    private String Street;
    private Integer HouseNo;
    private String HouseName;
    private String Area;
    private String PostCode;
    private String Town;
    private String Country;
    
    public IAddress(){
        Edit("","",0,"","","","","");
    }
    
    public void Display(javax.swing.JTextArea jAddressTextArea){
        jAddressTextArea.setLineWrap(true);
        jAddressTextArea.append("Name: "+Name+"\nStreet: "+Street+"\nHouse_No: "+HouseNo+"\nHouse_Name: "+HouseName+"\nArea: "+Area+
        "\nPostCode: "+PostCode+"\nTown: "+Town+"\nCountry: "+Country+"\n\n");
    }
    
    public String ToString(){
     String address=("Name: "+Name+"\nStreet: "+Street+"\nHouse_No: "+HouseNo+"\nHouse_Name: "+HouseName+"\nArea: "+Area+
        "\nPostCode: "+PostCode+"\nTown: "+Town+"\nCountry: "+Country+"\n\n");
     return address;
    }
    
    public void Edit(String strname,String strstreet,Integer inthouse_no,String strhouse_name,
            String strarea,String strpost_code,String strtown,String strcountry){
        this.Name=strname;
        this.Street=strstreet;
        this.HouseNo=inthouse_no;
        this.HouseName=strhouse_name;
        this.Area=strarea;
        this.PostCode=strpost_code;
        this.Town=strtown;
        this.Country=strcountry;
    }
    
    public String getName(){
        return Name;
    }
    public String getStreet(){
        return Street;
    }
    public Integer getHouseNo(){
        return HouseNo;
    }
    public String getHouseName(){
        return HouseName;
    }
    public String getArea(){
        return Area;
    }
    public String getPostCode(){
        return PostCode;
    }
    public String getTown(){
        return Town;
    }
    public String getCountry(){
        return Country;
    }
    
//    public String getAll(int i){
//        String All[]={Name,Street,String.valueOf(HouseNo),HouseName,Area,PostCode,Town,Country};
//        return All[i];
//    }
}
