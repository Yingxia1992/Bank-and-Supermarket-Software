/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstapplication;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author ee13yyl
 */
public abstract class Account {
    
    protected String FirstName;
    protected String Surname;
    protected String SortCode;
    protected Integer AccountNo;
    protected Double Balance;
    protected String NameOfBank;
    protected Double Rate;
//    private String LastReportedDate;
    private Customer ACustomer;
//     private File AccountFile;
     
    public Account(){
        setAccount("",0,0.,"","","");
        Rate=1.2;
//        LastReportedDate="01/01/1900";
//       ACustomer=new Customer();
    }
//    public Account(String strSC,Integer intAN,Double douBalance,String strNOB,String strFN,String strSN,Customer C){
//       setAccount(strSC,intAN,douBalance,strNOB,strFN,strSN);
//       setCustomer(C);
//       SaveToFile();
//    }
    public Account(Account src){
        setAccount(src.getSortCode(),src.getAccountNo(),src.getBalance(),src.getNOB(),src.getFirstName(),src.getSurname());
    }
    
    public Account(String strSC,Integer intAN,Double douBalance,String strNOB,String strFN,String strSN){
        this.SortCode=strSC;
        this.AccountNo=intAN;
        this.Balance=douBalance;
        this.NameOfBank=strNOB;
        this.FirstName=strFN;
        this.Surname=strSN;
    }
    
//    public Account Create(String strSC,Integer intAN,Double douBalance,String strNOB,String strFN,String strSN){
//        Account A=new Account();
//        A.setAccount(strSC, intAN, douBalance, strNOB, strFN, strSN);
//        SaveToFile();
//        return A;
//    }
    
    public void Display(javax.swing.JTextArea jAccountTextArea){

        jAccountTextArea.setLineWrap(true);
        jAccountTextArea.append("\n"+"\nSortCode: "+SortCode+"\nAccountNo: "+AccountNo+"\nBalance: "+Balance+"\nName of Bank: "+NameOfBank);
    }
    
    public String getSortCode(){
        return SortCode;
    }
    public Integer getAccountNo(){
        return AccountNo;
    }
    public Double getBalance(){
        return Balance;
    }
    public String getNOB(){
        return NameOfBank;
    }
    public String getFirstName(){
        return FirstName;
    }
    public String getSurname(){
        return Surname;
    }
    
    
    public void setAccount(String strSC,Integer intAN,Double douBalance,String strNOB,String strFN,String strSN){
        this.SortCode=strSC;
        this.AccountNo=intAN;
        this.Balance=douBalance;
        this.NameOfBank=strNOB;
        this.FirstName=strFN;
        this.Surname=strSN;
    }
    public File CreateDirectory(){
        File folder=new File("AccountFolder.txt");
        folder.mkdir();
        if(!folder.exists()){
            if(folder.mkdir()){
                System.out.println("AccoutFolder has been created");
            }
            else{
                System.out.println("Failed to create Account folder");
        }
        }
        return folder;
    }
    public abstract void Deposit(double Amount);
    public abstract void Withdrawal(double Amount);
    
    public Customer getCustomer(){
        return ACustomer;
    }
    
    public void setCustomer(Customer C){
        ACustomer=new Customer(C);
    }
//    public void setCustomerName(String FirstName,String Surname){
//        ACustomer.setName(FirstName, Surname);
//    }
//    
    public abstract File SaveToFile();
    public abstract Account LoadFromFile(String CurrentLine);
//    public File SaveToFile(){
//        ACustomer=new Customer();
//        File folder=new File("Accounts_Folder.txt");
//        folder.mkdir();
//        if(!folder.exists()){
//            if(folder.mkdir()){
//                System.out.println("AccoutFolder has been created");
//            }
//            else{
//                System.out.println("AccountFailed to create folder");
//        }
//        }
//        AccountFile=new File(folder+"/"+getSortCode()+"-load.txt");
//        FileWriter writer;
//        try{
//            writer=new FileWriter(AccountFile,true);
//            writer.write(SortCode+System.getProperty("line.separator"));
//            writer.write(AccountNo+System.getProperty("line.separator"));
//            writer.write(Balance+System.getProperty("line.separator"));
//            writer.write(NameOfBank+System.getProperty("line.separator"));
//            writer.write(FirstName+System.getProperty("line.separator"));
//            writer.write(Surname+System.getProperty("line.separator"));
//            writer.flush();
//            writer.close();
//            writer=null;
//            System.out.println("Save Account");
//        }catch(IOException ioe){
//            
//        }
//        return folder;
//    }
    
    public String ToString(){
        String Account=("\n"+"\nSortCode: "+SortCode+"\nAccountNo: "+AccountNo+"\nBalance: "+Balance+"\nName of Bank: "+NameOfBank);
        return Account;
    }
    
    public String getString(){
        return String.format(SortCode+"\n"+AccountNo+"\n"+Balance+"\n"+NameOfBank+"\n"+FirstName+"\n"+Surname+"\n");
    }
//    public Customer getCustomer(){
//        return ACustomer;
//    }
    
//    public Account getAccount(){
//        return this;
//    }
    
}
